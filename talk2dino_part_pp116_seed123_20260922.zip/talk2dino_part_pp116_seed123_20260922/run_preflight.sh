#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${PKG_DIR}/config.sh"
cd "${REPO_ROOT}"
ARGS=()
[[ -n "${DINO_REPO}" ]] && ARGS+=(--dino_repo "${DINO_REPO}")
python "${PKG_DIR}/preflight.py" \
  --repo_root "${REPO_ROOT}" \
  --image_root "${IMAGE_ROOT}" \
  --part_mask_root "${PART_MASK_ROOT}" \
  --text_bank "${TEXT_BANK}" \
  --model_config "${MODEL_CONFIG}" \
  --base_projector "${BASE_PROJECTOR}" \
  --dino_ckpt "${DINO_CKPT}" \
  "${ARGS[@]}" \
  --eval_cfg "${EVAL_CFG}" \
  --eval_base_cfg "${EVAL_BASE_CFG}"
