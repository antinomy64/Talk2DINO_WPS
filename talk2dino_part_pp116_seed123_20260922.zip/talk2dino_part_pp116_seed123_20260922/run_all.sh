#!/usr/bin/env bash
set -euo pipefail

PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${PKG_DIR}/config.sh"
cd "${REPO_ROOT}"
mkdir -p "${PKG_DIR}/cache" "${TRAIN_DIR}" "$(dirname "${FINAL_WEIGHT}")" "${EVAL_OUTPUT}" "${LOG_DIR}" "${RESULT_DIR}"

exec > >(tee -a "${LOG_DIR}/run_all.log") 2>&1

echo "=== Talk2DINO-Part PP-116 | seed=${SEED} ==="
echo "Package: ${PKG_DIR}"
echo "Repo:    ${REPO_ROOT}"
echo "Start:   $(date -Is)"

PREFLIGHT_DINO_ARGS=()
[[ -n "${DINO_REPO}" ]] && PREFLIGHT_DINO_ARGS+=(--dino_repo "${DINO_REPO}")
python "${PKG_DIR}/preflight.py" \
  --repo_root "${REPO_ROOT}" \
  --image_root "${IMAGE_ROOT}" \
  --part_mask_root "${PART_MASK_ROOT}" \
  --text_bank "${TEXT_BANK}" \
  --model_config "${MODEL_CONFIG}" \
  --base_projector "${BASE_PROJECTOR}" \
  --dino_ckpt "${DINO_CKPT}" \
  "${PREFLIGHT_DINO_ARGS[@]}" \
  --eval_cfg "${EVAL_CFG}" \
  --eval_base_cfg "${EVAL_BASE_CFG}" \
  2>&1 | tee "${LOG_DIR}/00_preflight.log"

if [[ ! -f "${MANIFEST}" ]]; then
  python "${PKG_DIR}/build_part_presence.py" \
    --image_root "${IMAGE_ROOT}" \
    --part_mask_root "${PART_MASK_ROOT}" \
    --output "${MANIFEST}" \
    --ignore "${PART_IGNORE}" \
    --id_offset "${PART_ID_OFFSET}" \
    --num_classes "${NUM_PART_CLASSES}" \
    2>&1 | tee "${LOG_DIR}/01_part_presence.log"
else
  echo "[reuse] manifest: ${MANIFEST}"
fi

if [[ ! -f "${DINO_CACHE}" ]]; then
  DINO_REPO_ARGS=()
  [[ -n "${DINO_REPO}" ]] && DINO_REPO_ARGS+=(--dino_repo "${DINO_REPO}")
  python "${PKG_DIR}/extract_dino_heads.py" \
    --project_root "${REPO_ROOT}" \
    --manifest "${MANIFEST}" \
    --output "${DINO_CACHE}" \
    "${DINO_REPO_ARGS[@]}" \
    --dino_ckpt "${DINO_CKPT}" \
    --model_name "${DINO_MODEL}" \
    --input_size "${DINO_INPUT_SIZE}" \
    --batch_size "${EXTRACT_BATCH_SIZE}" \
    --num_workers "${NUM_WORKERS}" \
    --dtype "${EXTRACT_DTYPE}" \
    --device "${DEVICE}" \
    --seed "${SEED}" \
    2>&1 | tee "${LOG_DIR}/02_extract_dino_heads.log"
else
  echo "[reuse] DINO head cache: ${DINO_CACHE}"
fi

python "${PKG_DIR}/train_talk2dino_part.py" \
  --project_root "${REPO_ROOT}" \
  --dino_cache "${DINO_CACHE}" \
  --text_bank "${TEXT_BANK}" \
  --model_config "${MODEL_CONFIG}" \
  --base_weights "${BASE_PROJECTOR}" \
  --out_dir "${TRAIN_DIR}" \
  --final_weight "${FINAL_WEIGHT}" \
  --epochs "${EPOCHS}" \
  --batch_size "${BATCH_SIZE}" \
  --lr "${LR}" \
  --temperature "${TEMPERATURE}" \
  --seed "${SEED}" \
  --device "${DEVICE}" \
  2>&1 | tee "${LOG_DIR}/03_train.log"

# evaluator prepends weights/ to model.proj_name. "../<package>/weights/name" escapes
# that directory while keeping every generated artifact inside this standalone package.
PROJ_REL="../$(basename "${PKG_DIR}")/weights/$(basename "${FINAL_WEIGHT}" .pth)"

python -m torch.distributed.run \
  --nproc_per_node=1 \
  --master_port="${MASTER_PORT}" \
  src/open_vocabulary_segmentation/main.py \
  --eval \
  --output "${EVAL_OUTPUT}" \
  --eval_cfg "${EVAL_CFG}" \
  --eval_base_cfg "${EVAL_BASE_CFG}" \
  --opts \
  model.proj_name="${PROJ_REL}" \
  evaluate.pamr=false \
  2>&1 | tee "${LOG_DIR}/04_eval.log"

python "${PKG_DIR}/summarize_result.py" \
  --eval_log "${LOG_DIR}/04_eval.log" \
  --output "${RESULT_DIR}/talk2dino_part_pp116_seed123.csv" \
  2>&1 | tee "${LOG_DIR}/05_summary.log"

echo "Done: $(date -Is)"
echo "Result: ${RESULT_DIR}/talk2dino_part_pp116_seed123.csv"
