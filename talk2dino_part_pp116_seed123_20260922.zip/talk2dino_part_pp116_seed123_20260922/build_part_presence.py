#!/usr/bin/env python3
"""Build non-spatial PP-116 image-level part labels from training part masks.

The mask is used ONLY to compute the set of class IDs present in each image.
No coordinates, shapes, areas, boxes, points, or masks are saved to the manifest.
"""
import argparse
from pathlib import Path
import json
import numpy as np
import torch
from PIL import Image


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--image_root', required=True)
    p.add_argument('--part_mask_root', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--ignore', type=int, default=255)
    p.add_argument('--id_offset', type=int, default=0)
    p.add_argument('--num_classes', type=int, default=116)
    return p.parse_args()


def index_files(root: Path, suffixes):
    out = {}
    for f in root.rglob('*'):
        if f.is_file() and f.suffix.lower() in suffixes:
            out.setdefault(f.stem, f)
    return out


def main():
    a = parse_args()
    image_root = Path(a.image_root).resolve()
    mask_root = Path(a.part_mask_root).resolve()
    out_path = Path(a.output).resolve()
    if not image_root.is_dir():
        raise FileNotFoundError(image_root)
    if not mask_root.is_dir():
        raise FileNotFoundError(mask_root)

    images = index_files(image_root, {'.jpg', '.jpeg', '.png', '.bmp'})
    masks = index_files(mask_root, {'.png', '.tif', '.tiff', '.bmp'})
    common = sorted(set(images) & set(masks))
    if not common:
        raise RuntimeError('No image/mask pairs found by matching file stem.')

    records = []
    missing_mask = sorted(set(images) - set(masks))
    bad = []
    class_freq = np.zeros(a.num_classes, dtype=np.int64)

    for stem in common:
        arr = np.asarray(Image.open(masks[stem]))
        if arr.ndim == 3:
            # Some indexed PNG readers may return replicated RGB channels.
            if np.array_equal(arr[..., 0], arr[..., 1]) and np.array_equal(arr[..., 0], arr[..., 2]):
                arr = arr[..., 0]
            else:
                bad.append((stem, f'non-indexed mask shape={arr.shape}'))
                continue
        if arr.ndim != 2:
            bad.append((stem, f'bad mask ndim={arr.ndim}'))
            continue
        ids = np.unique(arr.astype(np.int64))
        ids = ids[ids != a.ignore] - int(a.id_offset)
        ids = ids[(ids >= 0) & (ids < a.num_classes)]
        ids = sorted(set(int(x) for x in ids.tolist()))
        if not ids:
            continue
        for pid in ids:
            class_freq[pid] += 1
        records.append({
            'image_id': stem,
            'image_path': str(images[stem].resolve()),
            'part_ids': ids,
        })

    if bad:
        preview = '\n'.join(f'  {x}: {why}' for x, why in bad[:10])
        raise RuntimeError(f'Found {len(bad)} incompatible masks. First examples:\n{preview}')
    if not records:
        raise RuntimeError('No valid records after parsing masks.')

    payload = {
        'records': records,
        'meta': {
            'image_root': str(image_root),
            'part_mask_root': str(mask_root),
            'part_ignore': a.ignore,
            'part_id_offset': a.id_offset,
            'num_classes': a.num_classes,
            'num_images': len(records),
            'num_image_part_pairs': int(sum(len(r['part_ids']) for r in records)),
            'spatial_supervision_used': False,
            'note': 'Part masks were reduced to unique class-presence IDs only; no spatial mask data is retained.',
            'missing_mask_count': len(missing_mask),
            'class_image_frequency': class_freq.tolist(),
        },
    }
    out_path.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, out_path)
    (out_path.with_suffix('.json')).write_text(json.dumps(payload['meta'], indent=2), encoding='utf-8')
    print(f'Saved: {out_path}')
    print(f'Images: {len(records)}')
    print(f'Image-part pairs: {payload["meta"]["num_image_part_pairs"]}')
    print(f'Classes observed: {(class_freq > 0).sum()}/{a.num_classes}')
    if missing_mask:
        print(f'Images without matching mask (ignored): {len(missing_mask)}')


if __name__ == '__main__':
    main()
