#!/usr/bin/env python3
import argparse, glob, os, sys
from pathlib import Path
import torch
import torch.nn.functional as F
import yaml
from PIL import Image
import numpy as np


def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument('--repo_root', required=True); p.add_argument('--image_root', required=True)
    p.add_argument('--part_mask_root', required=True); p.add_argument('--text_bank', required=True)
    p.add_argument('--model_config', required=True); p.add_argument('--base_projector', required=True)
    p.add_argument('--dino_ckpt', required=True); p.add_argument('--dino_repo', default='')
    p.add_argument('--eval_cfg', required=True); p.add_argument('--eval_base_cfg', required=True)
    return p.parse_args()


def find_tensor(obj):
    if torch.is_tensor(obj): return obj
    if isinstance(obj,dict):
        for k in ('features','mean_feats','text_features','feats'):
            if k in obj and torch.is_tensor(obj[k]): return obj[k]
        xs=[v for v in obj.values() if torch.is_tensor(v) and v.ndim==2]
        if len(xs)==1:return xs[0]
    raise RuntimeError('Cannot identify text tensor')


def unwrap(obj):
    if isinstance(obj,dict):
        for k in ('model','state_dict','projector','projection_layer'):
            if k in obj and isinstance(obj[k],dict): return unwrap(obj[k])
    return obj


def main():
    a=parse_args(); root=Path(a.repo_root).resolve(); sys.path.insert(0,str(root))
    paths=[a.image_root,a.part_mask_root,a.text_bank,a.model_config,a.base_projector,a.dino_ckpt,a.eval_cfg,a.eval_base_cfg]
    for x in paths:
        if not Path(x).expanduser().exists(): raise FileNotFoundError(x)
    from src.model import ProjectionLayer
    from src.hooks import get_self_attention, process_self_attention, feats
    txt=find_tensor(torch.load(a.text_bank,map_location='cpu'))
    if txt.ndim!=2 or txt.shape[0]!=116: raise RuntimeError(f'Bad text bank shape: {tuple(txt.shape)}')
    with open(a.model_config,'r') as f:
        cfg=yaml.safe_load(f).get('model',{})
    if cfg.get('alignment_strategy','max_score') != 'max_score':
        raise RuntimeError(f"Expected alignment_strategy=max_score, got {cfg.get('alignment_strategy')}")
    if not cfg.get('cosine', True):
        raise RuntimeError('Talk2DINO-Part package requires cosine=True.')
    if cfg.get('weight_attn_heads', None) is not None:
        raise RuntimeError('This baseline expects disentangled heads with weight_attn_heads=None.')
    proj=ProjectionLayer.from_config(a.model_config)
    proj.load_state_dict(unwrap(torch.load(a.base_projector,map_location='cpu')),strict=True)
    with torch.no_grad(): y=proj.project_clip_txt(txt[:2].float())
    if y.shape[-1]!=768: raise RuntimeError(f'Expected projector dim 768, got {tuple(y.shape)}')
    # Verify the repo forward accepts disentangled heads and returns BxB logits.
    with torch.no_grad():
        fake_visual=torch.randn(2,12,768)
        fake_logits=proj(fake_visual, txt[:2].float(), ret_similarity_matrix=True)
    if tuple(fake_logits.shape)!=(2,2):
        raise RuntimeError(f'ProjectionLayer max_score forward returned {tuple(fake_logits.shape)}, expected (2,2)')
    repo=a.dino_repo or (sorted(glob.glob(os.path.expanduser('~/.cache/torch/hub/facebookresearch_dinov2_*')))[0] if glob.glob(os.path.expanduser('~/.cache/torch/hub/facebookresearch_dinov2_*')) else '')
    if not repo or not Path(repo).is_dir(): raise RuntimeError('No local DINOv2 repo found')
    # Basic dataset pairing/sample validation
    imgs={p.stem:p for p in Path(a.image_root).rglob('*') if p.suffix.lower() in {'.jpg','.jpeg','.png'}}
    masks={p.stem:p for p in Path(a.part_mask_root).rglob('*') if p.suffix.lower() in {'.png','.tif','.tiff','.bmp'}}
    common=sorted(set(imgs)&set(masks))
    if not common: raise RuntimeError('No image/mask pairs found')
    arr=np.asarray(Image.open(masks[common[0]]))
    print('=== Talk2DINO-Part preflight OK ===')
    print(f'repo_root: {root}')
    print(f'paired train images: {len(common)}')
    print(f'sample mask shape/dtype: {arr.shape}/{arr.dtype}')
    print(f'text bank: {tuple(txt.shape)}')
    print(f'projector output: {tuple(y.shape)}')
    print(f'projector max_score logits sanity: {tuple(fake_logits.shape)}')
    print(f'DINO repo: {repo}')
    print(f'DINO checkpoint: {Path(a.dino_ckpt).expanduser().resolve()}')
    print('Target protocol: full training images + image-level part presence only; no spatial part supervision.')
    print('Training: frozen CLIP features + frozen DINO heads; optimize projector only with max-head one-way InfoNCE.')

if __name__=='__main__': main()
