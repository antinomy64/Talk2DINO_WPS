#!/usr/bin/env python3
import argparse, csv, re
from pathlib import Path


def main():
    p=argparse.ArgumentParser(); p.add_argument('--eval_log',required=True); p.add_argument('--output',required=True); a=p.parse_args()
    text=Path(a.eval_log).read_text(errors='replace')
    miou=None; macc=None; aacc=None
    # Prefer the explicit Summary table.
    matches=list(re.finditer(r'\|\s*aAcc\s*\|\s*mIoU\s*\|\s*mAcc\s*\|\s*\n\+[^\n]+\+\s*\n\|\s*([0-9.]+)\s*\|\s*([0-9.]+)\s*\|\s*([0-9.]+)\s*\|', text))
    if matches:
        aacc,miou,macc=map(float,matches[-1].groups())
    if miou is None:
        xs=re.findall(r'mIoU of \d+ test images:\s*([0-9.]+)%',text)
        if xs: miou=float(xs[-1])
    if macc is None:
        xs=re.findall(r"'mAcc':\s*([0-9.eE+-]+)",text)
        if xs:
            v=float(xs[-1]); macc=v*100 if v<=1 else v
    if miou is None or macc is None:
        raise RuntimeError('Could not parse mIoU/mACC from eval log; inspect '+a.eval_log)
    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=['method','seed','mIoU','mACC','aAcc']); w.writeheader(); w.writerow({'method':'Talk2DINO-Part','seed':123,'mIoU':f'{miou:.2f}','mACC':f'{macc:.2f}','aAcc':'' if aacc is None else f'{aacc:.2f}'})
    print(f'Talk2DINO-Part: mIoU={miou:.2f}, mACC={macc:.2f}')
    print(f'Saved: {out}')
if __name__=='__main__': main()
