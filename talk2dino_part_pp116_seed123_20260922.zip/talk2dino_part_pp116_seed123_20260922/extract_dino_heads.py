#!/usr/bin/env python3
"""Extract Talk2DINO-style last-layer per-head visual embeddings for PP-116 images.

Faithfully mirrors the core official Talk2DINO/DINOv2 extraction idea:
- frozen DINOv2
- last-block qkv hook
- CLS-query attention to patch tokens
- softmax over patch positions per attention head
- attention-weighted normalized patch-token average per head

No part-mask spatial information is consumed here; only full training images are used.
"""
import argparse
import glob
import os
import sys
from pathlib import Path
import random
import numpy as np
import torch
from PIL import Image
from torch.utils.data import Dataset, DataLoader
from torchvision import transforms


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--project_root', required=True)
    p.add_argument('--manifest', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--dino_repo', default='')
    p.add_argument('--dino_ckpt', required=True)
    p.add_argument('--model_name', default='dinov2_vitb14_reg')
    p.add_argument('--input_size', type=int, default=448)
    p.add_argument('--batch_size', type=int, default=16)
    p.add_argument('--num_workers', type=int, default=4)
    p.add_argument('--dtype', choices=['float16', 'float32'], default='float16')
    p.add_argument('--device', default='cuda')
    p.add_argument('--seed', type=int, default=123)
    return p.parse_args()


def discover_repo(explicit=''):
    if explicit:
        p = Path(explicit).expanduser().resolve()
        if not p.is_dir():
            raise FileNotFoundError(f'DINO repo not found: {p}')
        return str(p)
    xs = sorted(glob.glob(os.path.expanduser('~/.cache/torch/hub/facebookresearch_dinov2_*')))
    if not xs:
        raise FileNotFoundError('No local DINOv2 torch-hub repo found under ~/.cache/torch/hub/facebookresearch_dinov2_*')
    return xs[0]


def unwrap_state_dict(obj):
    if isinstance(obj, dict):
        for k in ('model', 'state_dict', 'teacher', 'student'):
            if k in obj and isinstance(obj[k], dict):
                return unwrap_state_dict(obj[k])
    return obj


class ImageDataset(Dataset):
    def __init__(self, records, input_size):
        self.records = records
        self.tf = transforms.Compose([
            transforms.Resize(input_size, interpolation=transforms.InterpolationMode.BICUBIC),
            transforms.CenterCrop(input_size),
            transforms.ToTensor(),
            transforms.Normalize(mean=(0.485, 0.456, 0.406), std=(0.229, 0.224, 0.225)),
        ])
    def __len__(self): return len(self.records)
    def __getitem__(self, i):
        r = self.records[i]
        img = Image.open(r['image_path']).convert('RGB')
        return self.tf(img), i


def main():
    a = parse_args()
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    manifest = torch.load(a.manifest, map_location='cpu')
    records = manifest['records']
    if not records:
        raise RuntimeError('Empty manifest')

    project_root = Path(a.project_root).resolve()
    sys.path.insert(0, str(project_root))
    from src.hooks import get_self_attention, process_self_attention, feats

    repo = discover_repo(a.dino_repo)
    ckpt = Path(a.dino_ckpt).expanduser().resolve()
    if not ckpt.is_file(): raise FileNotFoundError(ckpt)
    print(f'[DINO] repo: {repo}', flush=True)
    print(f'[DINO] ckpt: {ckpt}', flush=True)
    print(f'[DINO] model: {a.model_name}', flush=True)

    model = torch.hub.load(repo, a.model_name, source='local', pretrained=False)
    sd = unwrap_state_dict(torch.load(ckpt, map_location='cpu'))
    # Strip common wrappers if necessary.
    if isinstance(sd, dict) and sd and all(isinstance(k, str) for k in sd):
        for prefix in ('module.', 'backbone.'):
            if all(k.startswith(prefix) for k in sd.keys()):
                sd = {k[len(prefix):]: v for k, v in sd.items()}
    msg = model.load_state_dict(sd, strict=True)
    print(f'[DINO] load_state_dict: {msg}', flush=True)
    device = torch.device(a.device)
    model = model.to(device).eval()

    last_attn = model.blocks[-1].attn
    num_heads = int(getattr(last_attn, 'num_heads', getattr(model, 'num_heads', 0)))
    if num_heads <= 0:
        raise RuntimeError('Could not infer DINO attention head count.')
    embed_dim = int(getattr(model, 'embed_dim', 0))
    if embed_dim <= 0:
        raise RuntimeError('Could not infer DINO embed_dim.')
    head_dim = embed_dim // num_heads
    scale = float(getattr(last_attn, 'scale', head_dim ** -0.5))
    num_register_tokens = int(getattr(model, 'num_register_tokens', 0))
    num_global_tokens = 1 + num_register_tokens
    print(f'[DINO] heads={num_heads}, dim={embed_dim}, global_tokens={num_global_tokens}, scale={scale}', flush=True)

    # Reuse the repository's own Talk2DINO attention hook/processor.
    handle = last_attn.qkv.register_forward_hook(get_self_attention)

    ds = ImageDataset(records, a.input_size)
    loader = DataLoader(ds, batch_size=a.batch_size, shuffle=False, num_workers=a.num_workers,
                        pin_memory=True, persistent_workers=(a.num_workers > 0))
    out_heads = [None] * len(records)
    save_dtype = torch.float16 if a.dtype == 'float16' else torch.float32
    num_patch_tokens = (a.input_size // 14) * (a.input_size // 14)
    num_tokens = num_global_tokens + num_patch_tokens

    try:
        with torch.inference_mode():
            for step, (images, indices) in enumerate(loader, 1):
                images = images.to(device, non_blocking=True)
                feats.clear()
                outs = model(images, is_training=True)
                if 'x_norm_patchtokens' not in outs:
                    raise RuntimeError(f'DINO output missing x_norm_patchtokens; keys={list(outs)}')
                if 'self_attn' not in feats:
                    raise RuntimeError('Repository get_self_attention hook did not fire.')
                B = images.shape[0]
                _, maps = process_self_attention(
                    feats['self_attn'], B, num_tokens, num_heads, embed_dim,
                    scale, num_global_tokens, ret_self_attn_maps=True
                )
                maps = maps.softmax(dim=-1)
                patch = outs['x_norm_patchtokens']
                if maps.shape[-1] != patch.shape[1]:
                    raise RuntimeError(f'Attention/patch mismatch: maps={maps.shape[-1]} patch={patch.shape[1]}')
                # Exactly the official extract_disentangled_self_attn computation.
                heads = (patch.unsqueeze(1) * maps.unsqueeze(-1)).mean(dim=2)
                heads = heads.to(dtype=save_dtype).cpu()
                for local_i, global_i in enumerate(indices.tolist()):
                    out_heads[global_i] = heads[local_i]
                if step == 1 or step % 25 == 0 or step == len(loader):
                    print(f'[extract] {min(step*a.batch_size, len(ds))}/{len(ds)}', flush=True)
    finally:
        handle.remove()

    if any(x is None for x in out_heads):
        raise RuntimeError('Extraction incomplete: some images have no head features.')
    head_tensor = torch.stack(out_heads, dim=0)  # [I,H,D]
    payload = {
        'heads': head_tensor,
        'records': [{'image_id': r['image_id'], 'part_ids': r['part_ids']} for r in records],
        'meta': {
            'model_name': a.model_name,
            'dino_ckpt': str(ckpt),
            'dino_repo': repo,
            'input_size': a.input_size,
            'num_images': len(records),
            'num_heads': num_heads,
            'embed_dim': embed_dim,
            'num_global_tokens': num_global_tokens,
            'formula': 'CLS-query last-layer attention over patch tokens; softmax; attention-weighted x_norm_patchtokens mean per head',
            'dtype': a.dtype,
        }
    }
    out = Path(a.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, out)
    print(f'Saved: {out}', flush=True)
    print(f'heads shape: {tuple(head_tensor.shape)} dtype={head_tensor.dtype}', flush=True)


if __name__ == '__main__':
    main()
