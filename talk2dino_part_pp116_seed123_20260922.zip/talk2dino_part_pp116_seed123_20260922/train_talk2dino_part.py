#!/usr/bin/env python3
"""PP-116 target adaptation using the original Talk2DINO max-head + InfoNCE objective.

Only the Talk2DINO projector is optimized. CLIP part features and DINO head visual
embeddings are frozen/cached.

For a batch of (image, part) pairs:
  1) project each part CLIP feature into DINO space;
  2) choose, independently for each positive image/text pair, the DINO attention-head
     visual embedding with maximum cosine similarity;
  3) form the batch text-to-selected-visual similarity matrix;
  4) apply the original one-direction InfoNCE / cross-entropy objective (paper Eq. 7).

Because PP-116 is multi-label, batches are constructed to contain no duplicate image
and no duplicate part ID, avoiding trivial same-image / same-text false negatives.
All image-part pairs are visited each epoch whenever a batch of >=2 can be formed.
"""
import argparse
import copy
import json
import math
import random
import sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument('--project_root', required=True)
    p.add_argument('--dino_cache', required=True)
    p.add_argument('--text_bank', required=True)
    p.add_argument('--model_config', required=True)
    p.add_argument('--base_weights', required=True)
    p.add_argument('--out_dir', required=True)
    p.add_argument('--final_weight', required=True)
    p.add_argument('--epochs', type=int, default=30)
    p.add_argument('--batch_size', type=int, default=16)
    p.add_argument('--lr', type=float, default=1e-5)
    p.add_argument('--temperature', type=float, default=1.0)
    p.add_argument('--seed', type=int, default=123)
    p.add_argument('--device', default='cuda')
    return p.parse_args()


def find_tensor(obj):
    if torch.is_tensor(obj): return obj
    if isinstance(obj, dict):
        for k in ('features', 'mean_feats', 'text_features', 'feats'):
            if k in obj and torch.is_tensor(obj[k]): return obj[k]
        tensors = [v for v in obj.values() if torch.is_tensor(v) and v.ndim == 2]
        if len(tensors) == 1: return tensors[0]
    raise RuntimeError('Could not identify [num_classes, text_dim] tensor in text bank.')


def unwrap_state_dict(obj):
    if isinstance(obj, dict):
        for k in ('model', 'state_dict', 'projector', 'projection_layer'):
            if k in obj and isinstance(obj[k], dict):
                return unwrap_state_dict(obj[k])
    return obj


def build_unique_batches(pairs, batch_size, seed):
    rng = random.Random(seed)
    remaining = list(pairs)
    rng.shuffle(remaining)
    batches = []
    # Greedy coloring into batches with unique image and part IDs.
    while remaining:
        used_img, used_part = set(), set()
        batch, deferred = [], []
        for pair in remaining:
            img_idx, part_id = pair
            if len(batch) < batch_size and img_idx not in used_img and part_id not in used_part:
                batch.append(pair); used_img.add(img_idx); used_part.add(part_id)
            else:
                deferred.append(pair)
        if not batch:
            raise RuntimeError('Batch construction stalled.')
        batches.append(batch)
        remaining = deferred
    rng.shuffle(batches)
    return batches


def main():
    a = parse_args()
    if a.batch_size < 2: raise ValueError('batch_size must be >=2 for InfoNCE')
    if a.temperature <= 0: raise ValueError('temperature must be >0')
    random.seed(a.seed); np.random.seed(a.seed); torch.manual_seed(a.seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(a.seed)

    project_root = Path(a.project_root).resolve()
    sys.path.insert(0, str(project_root))
    from src.model import ProjectionLayer

    device = torch.device(a.device)
    cache = torch.load(a.dino_cache, map_location='cpu')
    heads = cache['heads']
    records = cache['records']
    if heads.ndim != 3:
        raise RuntimeError(f'Expected heads [I,H,D], got {tuple(heads.shape)}')
    num_images, num_heads, visual_dim = heads.shape
    if len(records) != num_images:
        raise RuntimeError('Cache records/head count mismatch')
    # Float32 CPU master avoids repeated deserialization; batches are copied to GPU on demand.
    heads = heads.float().contiguous()

    text_obj = torch.load(a.text_bank, map_location='cpu')
    text_bank = find_tensor(text_obj).float().contiguous()
    if text_bank.ndim != 2 or text_bank.shape[0] != 116:
        raise RuntimeError(f'Expected PP-116 text bank [116,D], got {tuple(text_bank.shape)}')

    model_cfg_path = Path(a.model_config).resolve()
    projector = ProjectionLayer.from_config(str(model_cfg_path))
    sd = unwrap_state_dict(torch.load(a.base_weights, map_location='cpu'))
    projector.load_state_dict(sd, strict=True)
    projector = projector.to(device).train()
    for p in projector.parameters(): p.requires_grad_(True)

    # Validate projection dimensionality before training.
    with torch.no_grad():
        probe = projector.project_clip_txt(text_bank[:2].to(device))
    if probe.ndim != 2 or probe.shape[-1] != visual_dim:
        raise RuntimeError(f'Projector output dim {tuple(probe.shape)} != DINO dim {visual_dim}')

    pairs = []
    for i, r in enumerate(records):
        pids = sorted(set(int(x) for x in r['part_ids']))
        for pid in pids:
            if not (0 <= pid < text_bank.shape[0]):
                raise RuntimeError(f'Invalid part id {pid} for image {r["image_id"]}')
            pairs.append((i, pid))
    if not pairs: raise RuntimeError('No image-part pairs in cache.')

    opt = torch.optim.Adam(projector.parameters(), lr=a.lr)
    out_dir = Path(a.out_dir).resolve(); out_dir.mkdir(parents=True, exist_ok=True)
    final_weight = Path(a.final_weight).resolve(); final_weight.parent.mkdir(parents=True, exist_ok=True)
    history = []

    print(f'Images={num_images}, image-part pairs={len(pairs)}, heads={num_heads}, visual_dim={visual_dim}', flush=True)
    print(f'Training projector only: epochs={a.epochs}, batch={a.batch_size}, lr={a.lr}, temperature={a.temperature}, seed={a.seed}', flush=True)

    for epoch in range(1, a.epochs + 1):
        batches = build_unique_batches(pairs, a.batch_size, a.seed + epoch)
        losses = []
        selected_hist = torch.zeros(num_heads, dtype=torch.long)
        used_pairs = 0; skipped_pairs = 0; steps = 0
        projector.train()
        for batch in batches:
            if len(batch) < 2:
                skipped_pairs += len(batch)
                continue
            img_idx = torch.tensor([x[0] for x in batch], dtype=torch.long)
            part_id = torch.tensor([x[1] for x in batch], dtype=torch.long)
            visual = heads.index_select(0, img_idx).to(device, non_blocking=True)  # [B,H,D]
            raw_text = text_bank.index_select(0, part_id).to(device, non_blocking=True)

            # Use the repository's own ProjectionLayer.forward(): it projects text,
            # cosine-normalizes text/visual heads, applies alignment_strategy=max_score,
            # selects the best head for each positive pair, then returns BxB similarities.
            logits = projector(visual, raw_text, ret_similarity_matrix=True) / a.temperature
            labels = torch.arange(len(batch), device=device)
            loss = F.cross_entropy(logits, labels)

            # Head histogram is diagnostic only and does not affect the loss.
            with torch.no_grad():
                text_diag = F.normalize(projector.project_clip_txt(raw_text), dim=-1)
                visual_diag = F.normalize(visual, dim=-1)
                best = torch.einsum('bd,bhd->bh', text_diag, visual_diag).argmax(dim=1)

            opt.zero_grad(set_to_none=True)
            loss.backward()
            opt.step()

            losses.append(float(loss.detach().cpu()))
            selected_hist += torch.bincount(best.detach().cpu(), minlength=num_heads)
            used_pairs += len(batch); steps += 1

        mean_loss = float(np.mean(losses)) if losses else math.nan
        record = {
            'epoch': epoch, 'loss': mean_loss, 'steps': steps,
            'used_pairs': used_pairs, 'skipped_pairs': skipped_pairs,
            'selected_head_hist': selected_hist.tolist(),
        }
        history.append(record)
        epoch_weight = out_dir / f'projector_epoch_{epoch:03d}.pth'
        torch.save(projector.state_dict(), epoch_weight)
        torch.save(projector.state_dict(), out_dir / 'projector_last.pth')
        (out_dir / 'history.json').write_text(json.dumps(history, indent=2), encoding='utf-8')
        print(f'[epoch {epoch:03d}/{a.epochs}] loss={mean_loss:.6f} steps={steps} used={used_pairs} skipped={skipped_pairs}', flush=True)

    torch.save(projector.state_dict(), final_weight)
    print(f'Final evaluator-compatible projector: {final_weight}', flush=True)


if __name__ == '__main__':
    main()
