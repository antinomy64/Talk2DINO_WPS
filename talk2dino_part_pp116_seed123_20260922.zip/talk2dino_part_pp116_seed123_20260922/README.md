# Talk2DINO-Part — PP-116 controlled reproduction (seed 123)

This standalone package reproduces the **Talk2DINO-Part** target-adaptation baseline for the paper's controlled main comparison. It does **not modify any existing repository source/config file**. All generated manifests, DINO caches, checkpoints, weights, logs, evaluation outputs, and CSV results stay inside this package directory.

## Definition used

Stage 1 starts from the existing Talk2DINO projector trained only on **MS-COCO Captions 2014**:

`weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth`

Stage 2 adapts that projector on PP-116 with:

- the same PP-116 **training images**;
- only **image-level part presence labels**;
- frozen CLIP part features;
- frozen DINOv2 ViT-B/14-Reg visual features;
- the original Talk2DINO **last-layer attention-head visual embeddings**;
- the original **maximum-similarity head selection**;
- the original paper Eq. 7 **one-direction InfoNCE / cross-entropy** objective;
- **only the Talk2DINO projector is optimized**.

### Important fairness / supervision detail

The PP-116 part mask files are read only once by `build_part_presence.py` to convert each training image into a **set of present class IDs**. The package never retains or uses pixel coordinates, part shapes, boxes, points, masks, region averages, or any other spatial part information.

Unlike Ours, Talk2DINO-Part defaults to **full training images** rather than the Ours-specific predicted-object crop. This is deliberate: it preserves Talk2DINO's original image-text alignment mechanism while satisfying the paper's controlled requirement of the same target training images and image-level part labels. Using the Ours-specific crop would add a component that is not part of Talk2DINO itself.

## Fixed target-adaptation settings

- seed: 123
- epochs: 30
- Adam lr: 1e-5
- batch size: 16
- DINO input: 448 × 448
- evaluator: PP-116 full-image
- final evaluator PAMR: false

The loss temperature defaults to **1.0**, matching the paper Eq. 7 formulation with no explicit temperature term.

## Multi-label batching

PP-116 images have multiple part labels. Naively expanding every `(image, part)` pair into an ordinary InfoNCE batch can create false negatives (the same image or same part text appearing multiple times in a batch). To preserve Talk2DINO's one-positive-per-row training assumption while using all image-level part labels, `train_talk2dino_part.py` greedily constructs each batch so that:

- no image appears twice;
- no part ID appears twice.

The Talk2DINO max-head selection and InfoNCE objective themselves are unchanged.

## Run

Place this directory directly under the repository root, then:

```bash
chmod +x talk2dino_part_pp116_seed123_20260922/run_all.sh
nohup bash talk2dino_part_pp116_seed123_20260922/run_all.sh \
  > talk2dino_part_pp116_seed123_20260922/nohup.out 2>&1 &
echo $!
```

Monitor:

```bash
tail -f talk2dino_part_pp116_seed123_20260922/nohup.out
```

## Stages / resumability

`run_all.sh` performs:

1. strict preflight;
2. image-level PP-116 part-presence manifest;
3. Talk2DINO-style frozen DINO per-head feature cache;
4. 30-epoch projector adaptation;
5. PP-116 full-image evaluation (`evaluate.pamr=false`);
6. CSV result extraction.

The manifest and DINO cache are reused if they already exist, so a failed later stage does not require feature extraction again.

## Outputs

- `cache/pp116_part_presence.pt`
- `cache/pp116_dino_heads.pt`
- `checkpoints/projector_epoch_001.pth ... projector_epoch_030.pth`
- `weights/talk2dino_part_seed123.pth`
- `logs/04_eval.log`
- `results/talk2dino_part_pp116_seed123.csv`

## Preflight only

If you want to validate paths/projector/DINO cache before starting extraction:

```bash
source talk2dino_part_pp116_seed123_20260922/config.sh
python talk2dino_part_pp116_seed123_20260922/preflight.py \
  --repo_root "$REPO_ROOT" \
  --image_root "$IMAGE_ROOT" \
  --part_mask_root "$PART_MASK_ROOT" \
  --text_bank "$TEXT_BANK" \
  --model_config "$MODEL_CONFIG" \
  --base_projector "$BASE_PROJECTOR" \
  --dino_ckpt "$DINO_CKPT" \
  --eval_cfg "$EVAL_CFG" \
  --eval_base_cfg "$EVAL_BASE_CFG"
```


## Implementation fidelity checks

The package intentionally delegates the two most method-specific operations back to the repository:

- `extract_dino_heads.py` imports `src.hooks.get_self_attention`, `src.hooks.process_self_attention`, and `src.hooks.feats`, then applies the same `extract_disentangled_self_attn` computation used by Talk2DINO.
- `train_talk2dino_part.py` calls the repository's `ProjectionLayer.forward(...)` for the actual normalized max-head selection and B×B similarity computation; the standalone package only applies cross-entropy to that returned similarity matrix.

`preflight.py` also requires the loaded model config to use `alignment_strategy=max_score`, `cosine=true`, and no learned attention-head weighting, and verifies that the projector accepts `[B,H,768]` disentangled visual heads and returns a `[B,B]` similarity matrix.
