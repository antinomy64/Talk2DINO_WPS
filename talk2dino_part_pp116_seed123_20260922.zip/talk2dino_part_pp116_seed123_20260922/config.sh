#!/usr/bin/env bash
# Talk2DINO-Part PP-116 controlled adaptation config.
# This file is sourced by run_all.sh; edit only this standalone package if needed.

set -u

PKG_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${PKG_DIR}/.." && pwd)"

SEED=123
EPOCHS=30
BATCH_SIZE=16
LR=1e-5
TEMPERATURE=1.0
NUM_WORKERS=4
DEVICE=cuda

IMAGE_ROOT="${REPO_ROOT}/data/PascalPart116/images/train"
PART_MASK_ROOT="${REPO_ROOT}/data/PascalPart116/annotations_detectron2_part/train"
PART_IGNORE=255
PART_ID_OFFSET=0
NUM_PART_CLASSES=116

TEXT_BANK="${REPO_ROOT}/feature/pascalpart116_clip_text/pascalpart116_clip_vitb16_subimagenet_raw_reproduce.pt"
MODEL_CONFIG="${REPO_ROOT}/configs/vitb_mlp_infonce.yaml"
BASE_PROJECTOR="${REPO_ROOT}/weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth"

DINO_MODEL=dinov2_vitb14_reg
DINO_INPUT_SIZE=448
DINO_CKPT="${HOME}/.cache/torch/hub/checkpoints/dinov2_vitb14_reg4_pretrain.pth"
# DINO_REPO is auto-discovered under ~/.cache/torch/hub/facebookresearch_dinov2_* if empty.
DINO_REPO=""
EXTRACT_BATCH_SIZE=16
EXTRACT_DTYPE=float16

MANIFEST="${PKG_DIR}/cache/pp116_part_presence.pt"
DINO_CACHE="${PKG_DIR}/cache/pp116_dino_heads.pt"
TRAIN_DIR="${PKG_DIR}/checkpoints"
FINAL_WEIGHT="${PKG_DIR}/weights/talk2dino_part_seed123.pth"
EVAL_OUTPUT="${PKG_DIR}/eval_output"
LOG_DIR="${PKG_DIR}/logs"
RESULT_DIR="${PKG_DIR}/results"

EVAL_CFG="${REPO_ROOT}/src/open_vocabulary_segmentation/configs/voc116_part/dinotext_voc116_part_vitb_mlp_infonce.yml"
EVAL_BASE_CFG="${REPO_ROOT}/src/open_vocabulary_segmentation/configs/voc116_part/eval_voc116_part.yml"
MASTER_PORT=32831
