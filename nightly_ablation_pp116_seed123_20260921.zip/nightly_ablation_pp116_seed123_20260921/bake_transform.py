#!/usr/bin/env python3
"""Fold an arbitrary shared W into the final affine layer of Talk2DINO projector.
Works for both unconstrained Linear and Orthogonal ablations.
"""
import argparse, json, sys
from pathlib import Path
import torch


def tload(path):
    try: return torch.load(path,map_location="cpu",weights_only=False)
    except TypeError: return torch.load(path,map_location="cpu")


def unwrap_sd(o):
    if isinstance(o,dict):
        for k in ("state_dict","model","projector","proj"):
            if k in o and isinstance(o[k],dict): o=o[k]; break
    if o and all(str(k).startswith("module.") for k in o): o={str(k)[7:]:v for k,v in o.items()}
    return o


def getW(o):
    if torch.is_tensor(o): return o.float()
    if isinstance(o,dict):
        for k in ("W","transform","matrix"):
            if k in o and torch.is_tensor(o[k]): return o[k].float()
    raise RuntimeError("Cannot find W in transform checkpoint")


def bank_feats(o):
    if torch.is_tensor(o): return o
    if isinstance(o,dict):
        for k in ("features","mean_feats","text_features","feats"):
            if k in o and torch.is_tensor(o[k]): return o[k]
    raise RuntimeError("Cannot find features in text bank")


def main():
    p=argparse.ArgumentParser();
    p.add_argument("--project_root",required=True); p.add_argument("--projector",required=True); p.add_argument("--transform_checkpoint",required=True)
    p.add_argument("--text_bank",required=True); p.add_argument("--model_config",required=True); p.add_argument("--output",required=True); p.add_argument("--device",default="cuda")
    a=p.parse_args(); root=Path(a.project_root).resolve(); sys.path.insert(0,str(root))
    from src.model import ProjectionLayer
    sd=unwrap_sd(tload(root/a.projector)); W=getW(tload(a.transform_checkpoint)).cpu()
    D=W.shape[0]
    if W.ndim!=2 or W.shape[1]!=D: raise SystemExit(f"W must be square, got {tuple(W.shape)}")
    model=ProjectionLayer.from_config(str(root/a.model_config)); model.load_state_dict(sd,strict=True); model.eval()
    msd={k:v.detach().clone() for k,v in model.state_dict().items()}
    candidates=[]
    for k,v in msd.items():
        if k.endswith(".weight") and torch.is_tensor(v) and v.ndim==2 and tuple(v.shape)==(D,D): candidates.append(k)
    preferred=[k for k in candidates if "hidden_layers" in k or "linear_layer2" in k]
    key=(preferred or candidates)
    if len(key)!=1: raise SystemExit(f"Could not uniquely identify final {D}x{D} affine weight. candidates={candidates}")
    wk=key[0]; prefix=wk[:-len("weight")]; bk=prefix+"bias"
    if bk not in msd: raise SystemExit(f"Missing matching bias {bk}")
    A=msd[wk].float(); b=msd[bk].float()
    msd[wk]=(W.T@A).to(msd[wk].dtype)
    msd[bk]=(W.T@b).to(msd[bk].dtype)

    out=Path(a.output); out.parent.mkdir(parents=True,exist_ok=True); torch.save(msd,out)

    raw=bank_feats(tload(root/a.text_bank)).float()
    m0=ProjectionLayer.from_config(str(root/a.model_config)); m0.load_state_dict(sd,strict=True); m0.eval()
    m1=ProjectionLayer.from_config(str(root/a.model_config)); m1.load_state_dict(msd,strict=True); m1.eval()
    with torch.no_grad():
        y0=m0.project_clip_txt(raw).float()@W
        y1=m1.project_clip_txt(raw).float()
        max_abs=float((y0-y1).abs().max().item()); rel=float(torch.linalg.norm(y0-y1).item()/max(torch.linalg.norm(y0).item(),1e-12))
    meta={"source_projector":a.projector,"transform_checkpoint":a.transform_checkpoint,"weight_key":wk,"bias_key":bk,"max_abs_equivalence_error":max_abs,"relative_equivalence_error":rel}
    out.with_suffix(out.suffix+".json").write_text(json.dumps(meta,indent=2))
    print(json.dumps(meta,indent=2));
    if max_abs>2e-5: raise SystemExit(f"Bake equivalence check failed: max_abs={max_abs}")

if __name__=="__main__": main()
