#!/usr/bin/env bash
set -Eeuo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "${SCRIPT_DIR}/.." && pwd)"
source "${SCRIPT_DIR}/config.sh"
export PYTHONPATH="${REPO_ROOT}${PYTHONPATH:+:${PYTHONPATH}}"
cd "${REPO_ROOT}"

mkdir -p "${SCRIPT_DIR}/logs" "${SCRIPT_DIR}/runs/core" "${SCRIPT_DIR}/runs/prototype" "${SCRIPT_DIR}/weights" "${SCRIPT_DIR}/eval_outputs" "${SCRIPT_DIR}/results"
exec > >(tee -a "${SCRIPT_DIR}/logs/master.log") 2>&1

echo "=== PP-116 overnight ablations ==="
echo "repo=${REPO_ROOT}"
echo "suite=${SCRIPT_DIR}"
echo "seed=${SEED} epochs=${EPOCHS} batch=${BATCH_SIZE} lr=${LR} bg=${BG_THRESH} default_L=${DEFAULT_L}"
echo "final eval PAMR=false"

python "${SCRIPT_DIR}/preflight.py" \
  --repo_root "${REPO_ROOT}" --text_bank "${TEXT_BANK}" --train_cache "${TRAIN_CACHE}" \
  --model_config "${MODEL_CONFIG}" --projector "${BASE_PROJECTOR}" \
  --eval_main "${EVAL_MAIN}" --eval_cfg "${EVAL_CFG}" --eval_base_cfg "${EVAL_BASE_CFG}" \
  --expected_bg "${BG_THRESH}" --report "${SCRIPT_DIR}/logs/preflight.json"

# Record the repository state without modifying it.
{
  echo "date=$(date -Is)"
  echo "pwd=${REPO_ROOT}"
  git rev-parse HEAD 2>/dev/null | sed 's/^/git_head=/' || true
  git status --porcelain=v1 2>/dev/null | sed 's/^/git_status=/' || true
  sha256sum "${TEXT_BANK}" "${TRAIN_CACHE}" "${BASE_PROJECTOR}" "${MODEL_CONFIG}" 2>/dev/null || true
} > "${SCRIPT_DIR}/logs/repro_manifest.txt"

PORT=${MASTER_PORT_BASE}

write_meta() {
  local dir="$1" group="$2" run="$3" selector="$4" mapping="$5" L="$6"
  python - "$dir/run_meta.json" "$group" "$run" "$selector" "$mapping" "$L" "$SEED" <<'PY'
import json,sys
p,group,run,selector,mapping,L,seed=sys.argv[1:]
json.dump({"group":group,"run":run,"selector":selector,"mapping":mapping,"L":int(L),"seed":int(seed)},open(p,"w"),indent=2)
PY
}

eval_projector() {
  local group="$1" run="$2" proj_name="$3" selector="$4" mapping="$5" L="$6"
  local rdir="${SCRIPT_DIR}/runs/${group}/${run}"
  mkdir -p "$rdir" "${SCRIPT_DIR}/eval_outputs/${group}/${run}"
  write_meta "$rdir" "$group" "$run" "$selector" "$mapping" "$L"
  echo "[EVAL] ${group}/${run} proj=${proj_name} port=${PORT}"
  python -m torch.distributed.run \
    --nproc_per_node=1 --master_port="${PORT}" \
    "${EVAL_MAIN}" --eval \
    --output "${SCRIPT_DIR}/eval_outputs/${group}/${run}" \
    --eval_cfg "${EVAL_CFG}" --eval_base_cfg "${EVAL_BASE_CFG}" \
    --opts "model.proj_name=${proj_name}" evaluate.pamr=false \
    2>&1 | tee "$rdir/eval.log"
  PORT=$((PORT+1))
}

train_bake_eval() {
  local group="$1" run="$2" selector="$3" mapping="$4" L="$5"
  local rdir="${SCRIPT_DIR}/runs/${group}/${run}"
  local tdir="$rdir/train"
  local wfile="${SCRIPT_DIR}/weights/${run}.pth"
  mkdir -p "$tdir"
  write_meta "$rdir" "$group" "$run" "$selector" "$mapping" "$L"

  if [[ ! -f "$tdir/W_last.pt" ]]; then
    echo "[TRAIN] ${group}/${run}: selector=${selector} mapping=${mapping} L=${L}"
    python "${SCRIPT_DIR}/train_relproto_variant.py" \
      --project_root "${REPO_ROOT}" \
      --train_dataset "${TRAIN_CACHE}" \
      --text_bank "${TEXT_BANK}" \
      --model_config "${MODEL_CONFIG}" \
      --weights "${BASE_PROJECTOR}" \
      --out_dir "$tdir" \
      --selector "$selector" --mapping "$mapping" --prototype_max_patches "$L" \
      --epochs "$EPOCHS" --batch_size "$BATCH_SIZE" --lr "$LR" --seed "$SEED" \
      --expected_bg_thresh "$BG_THRESH" --require_pamr --require_cache_projector_match --device "$DEVICE" \
      2>&1 | tee "$rdir/train.log"
  else
    echo "[SKIP TRAIN] ${group}/${run}: W_last.pt exists"
  fi

  if [[ ! -f "$wfile" ]]; then
    echo "[BAKE] ${group}/${run}"
    python "${SCRIPT_DIR}/bake_transform.py" \
      --project_root "${REPO_ROOT}" --projector "${BASE_PROJECTOR}" \
      --transform_checkpoint "$tdir/W_last.pt" --text_bank "${TEXT_BANK}" \
      --model_config "${MODEL_CONFIG}" --output "$wfile" --device "$DEVICE" \
      2>&1 | tee "$rdir/bake.log"
  else
    echo "[SKIP BAKE] ${wfile} exists"
  fi

  # The evaluator joins proj_name under repository weights/. Using ../ keeps the
  # baked checkpoint physically inside this standalone suite.
  local suite_name
  suite_name="$(basename "${SCRIPT_DIR}")"
  local rel_proj="../${suite_name}/weights/${run}"
  eval_projector "$group" "$run" "$rel_proj" "$selector" "$mapping" "$L"
}

# ---------------------------------------------------------------------------
# Group 2: Core Ablation — exactly the five rows in the paper.
# Absolute baselines use the single highest absolute-similarity patch (L=1),
# matching the paper wording "highest absolute-similarity visual evidence".
# Relative variants use the default RelProto support size L=8.
# ---------------------------------------------------------------------------
echo "=== CORE ABLATION ==="
eval_projector "core" "talk2dino" "$BASE_PROJ_NAME" "none" "none" 0
train_bake_eval "core" "absolute_linear_L1"     "absolute" "linear"     1
train_bake_eval "core" "absolute_orthogonal_L1" "absolute" "orthogonal" 1
train_bake_eval "core" "relative_linear_L8"     "relative" "linear"     "$DEFAULT_L"
train_bake_eval "core" "relative_orthogonal_L8" "relative" "orthogonal" "$DEFAULT_L"

# ---------------------------------------------------------------------------
# Group 3: Relative Visual Prototype Design — strict L=1,...,16 sweep.
# Reuse the already-completed core Relative+Orthogonal L=8 result.
# ---------------------------------------------------------------------------
echo "=== PROTOTYPE L SWEEP ==="
for L in $(seq 1 16); do
  if [[ "$L" -eq "$DEFAULT_L" ]]; then
    src="${SCRIPT_DIR}/runs/core/relative_orthogonal_L8"
    dst="${SCRIPT_DIR}/runs/prototype/relative_orthogonal_L08"
    mkdir -p "$dst"
    cp -f "$src/eval.log" "$dst/eval.log"
    write_meta "$dst" "prototype" "relative_orthogonal_L08" "relative" "orthogonal" 8
    printf '%s\n' "reused_from=core/relative_orthogonal_L8" > "$dst/REUSED.txt"
    echo "[REUSE] prototype L=8 <- core relative_orthogonal_L8"
    continue
  fi
  printf -v tag "%02d" "$L"
  train_bake_eval "prototype" "relative_orthogonal_L${tag}" "relative" "orthogonal" "$L"
done

python "${SCRIPT_DIR}/summarize_results.py" --root "${SCRIPT_DIR}"

echo "=== ALL DONE ==="
echo "Core table:      ${SCRIPT_DIR}/results/core_ablation.csv"
echo "L sweep table:   ${SCRIPT_DIR}/results/prototype_L_sweep.csv"
echo "All results:     ${SCRIPT_DIR}/results/all_results.csv"
