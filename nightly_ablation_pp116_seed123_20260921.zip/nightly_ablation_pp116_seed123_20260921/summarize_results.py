#!/usr/bin/env python3
import argparse, csv, json, re
from pathlib import Path

FLOAT=r"[-+]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][-+]?\d+)?"

def extract_metric(text,name):
    pats=[
        rf"(?i)\b{name}\b\s*[:=]\s*({FLOAT})",
        rf"(?i)['\"]{name}['\"]\s*:\s*({FLOAT})",
        rf"(?i)\b{name}\b[^\n\r0-9+-]*({FLOAT})",
    ]
    vals=[]
    for pat in pats:
        vals += [float(x) for x in re.findall(pat,text)]
    return vals[-1] if vals else None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument("--root",required=True); a=ap.parse_args(); root=Path(a.root)
    rows=[]
    for meta_path in sorted(root.glob("runs/**/run_meta.json")):
        meta=json.loads(meta_path.read_text()); log=meta_path.parent/"eval.log"; txt=log.read_text(errors="ignore") if log.exists() else ""
        rows.append({**meta,"mIoU":extract_metric(txt,"mIoU"),"mACC":extract_metric(txt,"mACC"),"eval_log":str(log.relative_to(root)) if log.exists() else ""})
    out=root/"results"; out.mkdir(exist_ok=True)
    keys=["group","run","selector","mapping","L","seed","mIoU","mACC","eval_log"]
    with (out/"all_results.csv").open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); [w.writerow({k:r.get(k,"") for k in keys}) for r in rows]
    core=[r for r in rows if r.get("group")=="core"]
    sweep=sorted([r for r in rows if r.get("group")=="prototype"],key=lambda r:int(r.get("L",0)))
    for name,data in (("core_ablation.csv",core),("prototype_L_sweep.csv",sweep)):
        with (out/name).open("w",newline="") as f:
            w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); [w.writerow({k:r.get(k,"") for k in keys}) for r in data]
    print(f"Wrote {out/'all_results.csv'}")
    print(f"Wrote {out/'core_ablation.csv'}")
    print(f"Wrote {out/'prototype_L_sweep.csv'}")
