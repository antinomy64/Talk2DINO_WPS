#!/usr/bin/env python3
"""Standalone PP-116 RelProto variant trainer.

Implements the paper ablations without changing repository source files:
  selector: absolute | relative
  mapping:  linear | orthogonal

Canonical text path:
  raw CLIP [116,512] -> frozen Talk2DINO projector -> L2 norm -> T0
  adapted text = L2Norm(T0 @ W)

Relative prototype:
  R_jp = S_jp - max_{k!=j} S_kp
  anchor = argmax R_jp
  support = anchor + top-(L-1) non-anchor patches with R_jp > 0
  prototype = normalized mean of selected normalized DINO patch tokens

Absolute baseline in the paper is run with L=1 (highest absolute-similarity evidence).
"""
import argparse, json, math, os, random, sys, time
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F


def tload(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def seed_all(seed):
    random.seed(seed); np.random.seed(seed); torch.manual_seed(seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(seed)


def get_text_features(bank):
    if torch.is_tensor(bank): return bank
    if isinstance(bank, dict):
        for k in ("features", "mean_feats", "text_features", "feats"):
            if k in bank and torch.is_tensor(bank[k]): return bank[k]
    raise RuntimeError("Could not find text features in text bank")


def unwrap_state_dict(obj):
    if isinstance(obj, dict):
        for k in ("state_dict", "model", "projector", "proj"):
            if k in obj and isinstance(obj[k], dict):
                obj = obj[k]; break
    if not isinstance(obj, dict):
        raise RuntimeError("Projector checkpoint is not a state_dict-like object")
    if obj and all(str(k).startswith("module.") for k in obj):
        obj = {str(k)[7:]: v for k, v in obj.items()}
    return obj


def parts_to_list(x):
    if torch.is_tensor(x): x = x.detach().cpu().reshape(-1).tolist()
    elif isinstance(x, np.ndarray): x = x.reshape(-1).tolist()
    elif isinstance(x, (list, tuple, set)): x = list(x)
    else: x = [x]
    out=[]
    for z in x:
        if torch.is_tensor(z): z=z.item()
        try: z=int(z)
        except Exception: continue
        if 0 <= z < 116 and z not in out: out.append(z)
    return out


def canonicalize_annotation(a):
    if not isinstance(a, dict): return None
    if not all(k in a for k in ("cropaug_patch_tokens", "pred_obj_mask_patch", "part_category_id")): return None
    x = torch.as_tensor(a["cropaug_patch_tokens"]).detach().cpu()
    if x.ndim == 3 and x.shape[0] == 1: x=x[0]
    if x.ndim != 2: return None
    m = torch.as_tensor(a["pred_obj_mask_patch"]).detach().cpu().reshape(-1) > 0
    if m.numel() != x.shape[0] or not bool(m.any()): return None
    c = parts_to_list(a["part_category_id"])
    if not c: return None
    return x, m, c


def relative_scores(S):
    # S: [C,P]
    C, P = S.shape
    if C == 1: return S
    # max over all other rows, exactly matching R_jp definition.
    out=[]
    for j in range(C):
        other = torch.cat([S[:j], S[j+1:]], dim=0)
        out.append(S[j] - other.max(dim=0).values)
    return torch.stack(out, dim=0)


def build_proto(X, score_row, L, selector):
    # X [P,D] normalized. Selection is intentionally non-differentiable.
    vals = score_row.detach()
    anchor = int(vals.argmax().item())
    idx=[anchor]
    if L > 1:
        keep = torch.ones_like(vals, dtype=torch.bool)
        keep[anchor] = False
        if selector == "relative":
            keep &= vals > 0
        else:
            # Not used by the paper's Absolute baselines (which use L=1),
            # but defined for completeness if explicitly requested.
            keep &= torch.isfinite(vals)
        cand = torch.where(keep)[0]
        if cand.numel() > 0:
            k=min(L-1, int(cand.numel()))
            top_local=torch.topk(vals[cand], k=k, largest=True).indices
            idx.extend(cand[top_local].tolist())
    p = F.normalize(X[idx].mean(dim=0, keepdim=True), dim=-1)[0]
    return p, idx


def parse_args():
    p=argparse.ArgumentParser()
    p.add_argument("--project_root", required=True)
    p.add_argument("--train_dataset", required=True)
    p.add_argument("--text_bank", required=True)
    p.add_argument("--model_config", required=True)
    p.add_argument("--weights", required=True)
    p.add_argument("--out_dir", required=True)
    p.add_argument("--selector", choices=["absolute","relative"], required=True)
    p.add_argument("--mapping", choices=["linear","orthogonal"], required=True)
    p.add_argument("--prototype_max_patches", type=int, required=True)
    p.add_argument("--epochs", type=int, default=30)
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--lr", type=float, default=1e-5)
    p.add_argument("--seed", type=int, default=123)
    p.add_argument("--expected_bg_thresh", type=float, default=0.55)
    p.add_argument("--require_pamr", action="store_true")
    p.add_argument("--require_cache_projector_match", action="store_true")
    p.add_argument("--device", default="cuda")
    return p.parse_args()


def recursive_pairs(obj, frag, path="root"):
    ans=[]
    if isinstance(obj, dict):
        for k,v in obj.items():
            p=f"{path}.{k}"
            if frag.lower() in str(k).lower(): ans.append((p,v))
            if isinstance(v,(dict,list,tuple)): ans.extend(recursive_pairs(v,frag,p))
    elif isinstance(obj,(list,tuple)):
        for i,v in enumerate(obj[:20]):
            if isinstance(v,(dict,list,tuple)): ans.extend(recursive_pairs(v,frag,f"{path}[{i}]"))
    return ans


def main():
    a=parse_args(); seed_all(a.seed)
    root=Path(a.project_root).resolve(); out=Path(a.out_dir).resolve(); out.mkdir(parents=True,exist_ok=True)
    if a.prototype_max_patches < 1: raise SystemExit("prototype_max_patches must be >=1")
    sys.path.insert(0,str(root))
    from src.model import ProjectionLayer

    cache=tload(root/a.train_dataset)
    if not isinstance(cache,dict) or "annotations" not in cache: raise SystemExit("cache lacks annotations")
    meta=cache.get("pred_obj_cropaug_meta",{})
    bg=[]
    for p,v in recursive_pairs(meta,"bg_thresh"):
        if torch.is_tensor(v) and v.numel()==1: v=v.item()
        if isinstance(v,(int,float)): bg.append((p,float(v)))
    if bg and not any(abs(v-a.expected_bg_thresh)<1e-8 for _,v in bg):
        raise SystemExit(f"cache bg threshold mismatch: {bg} vs {a.expected_bg_thresh}")
    if a.require_pamr:
        ph=[]
        for p,v in recursive_pairs(meta,"pamr"):
            if torch.is_tensor(v) and v.numel()==1: v=v.item()
            if isinstance(v,bool): ph.append((p,v))
        if ph and not any(v for _,v in ph): raise SystemExit(f"cache metadata says PAMR disabled: {ph}")
    if a.require_cache_projector_match:
        hits=[]
        for p,v in recursive_pairs(meta,"projector"):
            if isinstance(v,(str,Path)): hits.append((p,str(v)))
        if hits:
            want=Path(a.weights).name
            if not any(Path(v).name==want for _,v in hits if v.endswith(".pth")):
                print(f"[WARN] projector metadata found but no exact basename match to {want}: {hits[:8]}",flush=True)

    raw=get_text_features(tload(root/a.text_bank)).float()
    if raw.ndim!=2 or raw.shape[0]!=116: raise SystemExit(f"text bank shape {tuple(raw.shape)} != [116,D]")
    device=torch.device(a.device)
    proj=ProjectionLayer.from_config(str(root/a.model_config))
    proj.load_state_dict(unwrap_state_dict(tload(root/a.weights)),strict=True)
    proj.to(device).eval().requires_grad_(False)
    with torch.no_grad():
        T0=F.normalize(proj.project_clip_txt(raw.to(device)),dim=-1).detach()
    D=T0.shape[1]
    if D!=768: raise SystemExit(f"expected projected dim 768, got {D}")

    dataset=[]; skipped=0
    for ann in cache["annotations"]:
        z=canonicalize_annotation(ann)
        if z is None: skipped+=1
        else: dataset.append(z)
    if not dataset: raise SystemExit("no valid cache annotations")
    print(f"valid objects={len(dataset)} skipped={skipped} selector={a.selector} mapping={a.mapping} L={a.prototype_max_patches}",flush=True)

    W=torch.nn.Parameter(torch.eye(D,device=device,dtype=torch.float32))
    opt=torch.optim.Adam([W],lr=a.lr)
    history=[]
    start=time.time()
    for ep in range(1,a.epochs+1):
        gen=torch.Generator().manual_seed(a.seed+ep)
        order=torch.randperm(len(dataset),generator=gen).tolist()
        total=0.0; nobj=0; nparts=0; nsupp=0
        for st in range(0,len(order),a.batch_size):
            batch=order[st:st+a.batch_size]
            obj_losses=[]; bparts=0; bsupp=0
            for ii in batch:
                x_cpu,m_cpu,C=dataset[ii]
                X=F.normalize(x_cpu[m_cpu].to(device=device,dtype=torch.float32),dim=-1)
                ids=torch.tensor(C,device=device,dtype=torch.long)
                T=F.normalize(T0.index_select(0,ids) @ W,dim=-1)
                S=T @ X.T
                score=S if a.selector=="absolute" else relative_scores(S)
                losses=[]
                for j in range(len(C)):
                    proto,idx=build_proto(X,score[j],a.prototype_max_patches,a.selector)
                    losses.append(1.0 - (T[j]*proto.detach()).sum())
                    bsupp += len(idx)
                if losses:
                    obj_losses.append(torch.stack(losses).mean())
                    bparts += len(losses)
            if not obj_losses: continue
            loss=torch.stack(obj_losses).mean()
            opt.zero_grad(set_to_none=True); loss.backward(); opt.step()
            if a.mapping=="orthogonal":
                with torch.no_grad():
                    U,_,Vh=torch.linalg.svd(W,full_matrices=False)
                    W.copy_(U@Vh)
            total += float(loss.detach())*len(obj_losses); nobj += len(obj_losses); nparts += bparts; nsupp += bsupp
        mean=total/max(nobj,1)
        with torch.no_grad():
            ortho=float((W.T@W-torch.eye(D,device=device)).abs().max().item())
            drift=float(torch.linalg.norm(W-torch.eye(D,device=device)).item())
        rec={"epoch":ep,"loss":mean,"objects":nobj,"parts":nparts,"mean_support":nsupp/max(nparts,1),"orthogonality_max_abs":ortho,"W_minus_I_fro":drift}
        history.append(rec)
        ck={"W":W.detach().cpu(),"epoch":ep,"selector":a.selector,"mapping":a.mapping,"prototype_max_patches":a.prototype_max_patches,"seed":a.seed,"lr":a.lr,"batch_size":a.batch_size,"history":history}
        torch.save(ck,out/f"W_epoch_{ep:03d}.pt"); torch.save(ck,out/"W_last.pt")
        (out/"history.json").write_text(json.dumps(history,indent=2))
        print(f"epoch {ep:03d}/{a.epochs} loss={mean:.6f} support={rec['mean_support']:.3f} ortho_err={ortho:.3e} drift={drift:.4f}",flush=True)

    torch.save({"features":T0.detach().cpu(),"stage":"post_frozen_object_projector_l2norm"},out/"projected_text_bank.pt")
    args_dict=vars(a).copy(); args_dict["elapsed_sec"]=time.time()-start; args_dict["valid_objects"]=len(dataset); args_dict["skipped_objects"]=skipped
    (out/"args.json").write_text(json.dumps(args_dict,indent=2))
    print(f"DONE {out}",flush=True)

if __name__=="__main__": main()
