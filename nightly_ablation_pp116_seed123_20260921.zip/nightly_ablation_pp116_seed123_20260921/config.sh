#!/usr/bin/env bash
# Paper-locked PP-116 settings for 2026-09-21 overnight ablations.
# This file only defines variables; it does not modify repository files.

SEED=123
EPOCHS=30
BATCH_SIZE=16
LR=1e-5
BG_THRESH=0.55
DEFAULT_L=8
DEVICE=cuda

TEXT_BANK="feature/pascalpart116_clip_text/pascalpart116_clip_vitb16_subimagenet_raw_reproduce.pt"
TRAIN_CACHE="feature/pascalpart116_predobj_clip_struct/train_predobj_cropaug_bg055_reproduce.pth"
MODEL_CONFIG="configs/vitb_mlp_infonce.yaml"
BASE_PROJECTOR="weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth"
BASE_PROJ_NAME="vitb_mlp_infonce_coco2014_reproduce_clean"

EVAL_MAIN="src/open_vocabulary_segmentation/main.py"
EVAL_CFG="src/open_vocabulary_segmentation/configs/voc116_part/dinotext_voc116_part_vitb_mlp_infonce.yml"
EVAL_BASE_CFG="src/open_vocabulary_segmentation/configs/voc116_part/eval_voc116_part.yml"
MASTER_PORT_BASE=32623
