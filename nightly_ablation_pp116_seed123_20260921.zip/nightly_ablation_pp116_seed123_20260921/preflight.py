#!/usr/bin/env python3
import argparse, json, os, sys
from pathlib import Path
import torch


def tload(path):
    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(path, map_location="cpu")


def recursive_find(obj, key_fragment, path="root"):
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            p = f"{path}.{k}"
            if key_fragment.lower() in str(k).lower():
                out.append((p, v))
            if isinstance(v, (dict, list, tuple)):
                out.extend(recursive_find(v, key_fragment, p))
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj[:20]):
            if isinstance(v, (dict, list, tuple)):
                out.extend(recursive_find(v, key_fragment, f"{path}[{i}]"))
    return out


def get_features(bank):
    if torch.is_tensor(bank):
        return bank
    if isinstance(bank, dict):
        for k in ("features", "mean_feats", "text_features", "feats"):
            if k in bank and torch.is_tensor(bank[k]):
                return bank[k]
    raise RuntimeError("Could not locate text features tensor in text bank")


def scalar(v):
    if torch.is_tensor(v) and v.numel() == 1:
        return v.item()
    if isinstance(v, (int, float, bool, str)):
        return v
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo_root", required=True)
    ap.add_argument("--text_bank", required=True)
    ap.add_argument("--train_cache", required=True)
    ap.add_argument("--model_config", required=True)
    ap.add_argument("--projector", required=True)
    ap.add_argument("--eval_main", required=True)
    ap.add_argument("--eval_cfg", required=True)
    ap.add_argument("--eval_base_cfg", required=True)
    ap.add_argument("--expected_bg", type=float, default=0.55)
    ap.add_argument("--report", required=True)
    args = ap.parse_args()

    root = Path(args.repo_root).resolve()
    req = {
        "text_bank": args.text_bank,
        "train_cache": args.train_cache,
        "model_config": args.model_config,
        "projector": args.projector,
        "eval_main": args.eval_main,
        "eval_cfg": args.eval_cfg,
        "eval_base_cfg": args.eval_base_cfg,
        "src_model": "src/model.py",
    }
    missing = [f"{k}: {v}" for k, v in req.items() if not (root / v).is_file()]
    if missing:
        raise SystemExit("Missing required repository inputs:\n  " + "\n  ".join(missing))

    bank = tload(root / args.text_bank)
    feat = get_features(bank)
    if feat.ndim != 2 or feat.shape[0] != 116:
        raise SystemExit(f"Unexpected text bank shape {tuple(feat.shape)}; expected [116,D]")

    cache = tload(root / args.train_cache)
    if not isinstance(cache, dict) or "annotations" not in cache:
        raise SystemExit("Training cache must be a dict containing key 'annotations'")
    anns = cache["annotations"]
    if not isinstance(anns, (list, tuple)) or len(anns) == 0:
        raise SystemExit("Training cache annotations are empty or not a list")

    sample = None
    for a in anns:
        if isinstance(a, dict) and all(k in a for k in ("cropaug_patch_tokens", "pred_obj_mask_patch", "part_category_id")):
            sample = a
            break
    if sample is None:
        keys = sorted(anns[0].keys()) if isinstance(anns[0], dict) else type(anns[0]).__name__
        raise SystemExit(f"No annotation with required keys found. First annotation keys/type: {keys}")

    tokens = torch.as_tensor(sample["cropaug_patch_tokens"])
    mask = torch.as_tensor(sample["pred_obj_mask_patch"])
    if tokens.ndim == 3 and tokens.shape[0] == 1:
        tokens = tokens[0]
    if tokens.ndim != 2 or tokens.shape[-1] != 768:
        raise SystemExit(f"Unexpected cropaug_patch_tokens shape {tuple(tokens.shape)}; expected [N,768]")
    if mask.numel() != tokens.shape[0]:
        raise SystemExit(f"pred_obj_mask_patch has {mask.numel()} elements but tokens have N={tokens.shape[0]}")

    meta = cache.get("pred_obj_cropaug_meta", {})
    bg_hits = [(p, scalar(v)) for p, v in recursive_find(meta, "bg_thresh")]
    bg_vals = [(p, v) for p, v in bg_hits if isinstance(v, (int, float))]
    if bg_vals and not any(abs(float(v)-args.expected_bg) < 1e-8 for _, v in bg_vals):
        raise SystemExit(f"Cache bg_thresh mismatch: found {bg_vals}, expected {args.expected_bg}")

    pamr_hits = [(p, scalar(v)) for p, v in recursive_find(meta, "pamr")]
    pamr_bools = [(p, v) for p, v in pamr_hits if isinstance(v, bool)]
    if pamr_bools and not any(v for _, v in pamr_bools):
        raise SystemExit(f"Cache metadata says PAMR is disabled: {pamr_bools}")

    proj_hits = [(p, scalar(v)) for p, v in recursive_find(meta, "projector")]

    report = {
        "repo_root": str(root),
        "text_bank": args.text_bank,
        "text_bank_shape": list(feat.shape),
        "train_cache": args.train_cache,
        "num_annotations": len(anns),
        "sample_token_shape": list(tokens.shape),
        "sample_foreground_patches": int((mask.reshape(-1) > 0).sum().item()),
        "sample_part_category_id": str(sample["part_category_id"]),
        "bg_metadata_hits": bg_hits,
        "pamr_metadata_hits": pamr_hits,
        "projector_metadata_hits": proj_hits[:20],
        "checks": "PASS",
    }
    Path(args.report).parent.mkdir(parents=True, exist_ok=True)
    Path(args.report).write_text(json.dumps(report, indent=2, default=str))
    print(json.dumps(report, indent=2, default=str))

if __name__ == "__main__":
    main()
