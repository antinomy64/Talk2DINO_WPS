#!/usr/bin/env python3
"""
Run the repository's extract_predobj_cropaug.py without editing it, but replace
the object text features used for Talk2DINO object prediction by a precomputed
raw text bank (e.g. LLaMA3 [20,4096]) projected by the loaded projector.

The repository DINOText object may still instantiate CLIP internally because
that is part of its constructor; this wrapper never calls CLIP to create the
object semantic text features.
"""
from __future__ import annotations
import argparse, sys
from pathlib import Path
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

from text_bank_utils import load_raw_bank

def main():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--raw_object_bank", required=True)
    known, rest = p.parse_known_args()
    sys.argv = [sys.argv[0]] + rest

    import extract_predobj_cropaug as base

    raw, names, _ = load_raw_bank(known.raw_object_bank, expected_rows=20)
    if names != list(base.VOC20_CLASSES):
        raise ValueError(
            "LLaMA object-bank taxonomy/order mismatch.\n"
            f"bank={names}\nexpected={list(base.VOC20_CLASSES)}"
        )

    original_build_model = base.build_model

    def patched_build_model(args, repo, device):
        model, weight = original_build_model(args, repo, device)
        expected_dim = int(model.proj.linear_layer.in_features)
        if raw.shape[1] != expected_dim:
            raise ValueError(
                f"raw object bank dim={raw.shape[1]} but projector input={expected_dim}"
            )

        with torch.inference_mode():
            z = model.proj.project_clip_txt(
                raw.to(device=device, dtype=torch.float32)
            )
            z = F.normalize(z.float(), dim=-1).contiguous()
        if tuple(z.shape) != (20, 768):
            raise ValueError(f"projected object bank shape={tuple(z.shape)}")

        # extract_predobj_cropaug.main() calls these two methods once to build
        # the full 20-class bank. Return an opaque sentinel then the precomputed bank.
        def build_dataset_class_tokens(_template, classnames):
            cls = [str(x) for x in classnames]
            if cls != names:
                raise ValueError(f"requested object taxonomy differs from bank: {cls}")
            return ("__PRECOMPUTED_RAW_TEXT_BANK__", tuple(cls))

        def build_text_embedding(tokens):
            if not (
                isinstance(tokens, tuple)
                and len(tokens) == 2
                and tokens[0] == "__PRECOMPUTED_RAW_TEXT_BANK__"
            ):
                raise TypeError("unexpected token payload in precomputed-text wrapper")
            return z

        model.build_dataset_class_tokens = build_dataset_class_tokens
        model.build_text_embedding = build_text_embedding
        print("[nightly] object semantic text source: PRECOMPUTED RAW BANK")
        print("[nightly] raw object bank:", Path(known.raw_object_bank).resolve())
        print("[nightly] raw dim:", raw.shape[1])
        return model, weight

    base.build_model = patched_build_model
    base.main()

if __name__ == "__main__":
    main()
