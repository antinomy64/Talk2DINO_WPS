#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1

cd "$(git rev-parse --show-toplevel)"
SUITE="paper_ablation_nightly_bg055_nopamr"

GPU="${GPU:-0}"
RUN_ROOT="${RUN_ROOT:?RUN_ROOT must be set}"
EPOCH_SWEEP_DIR="${EPOCH_SWEEP_DIR:-final_exp/relproto_alignment/main_seed123_bg055_L4}"
CLIP_WEIGHT="${CLIP_WEIGHT:-weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth}"
CLIP_PART_BANK="${CLIP_PART_BANK:-feature/pascalpart116_clip_text/pascalpart116_clip_vitb16_subimagenet_raw_reproduce.pt}"
CLIP_CFG="${CLIP_CFG:-configs/vitb_mlp_infonce.yaml}"
WAIT_FOR_CHECKPOINTS="${WAIT_FOR_CHECKPOINTS:-1}"
WAIT_POLL_SECONDS="${WAIT_POLL_SECONDS:-30}"
WAIT_MAX_SECONDS="${WAIT_MAX_SECONDS:-0}"  # 0 = no timeout

TAG="$(basename "$RUN_ROOT")"
mkdir -p "$RUN_ROOT/epoch_sweep" "$RUN_ROOT/logs" weights

for f in "$CLIP_WEIGHT" "$CLIP_PART_BANK" "$CLIP_CFG"; do
  test -f "$f" || { echo "[ERROR] missing $f"; exit 2; }
done

echo "============================================================"
echo "EPOCH 001..100 DENSE EVALUATION SWEEP"
echo "checkpoint dir : $EPOCH_SWEEP_DIR"
echo "final PAMR     : FALSE"
echo "============================================================"

for E in $(seq 1 100); do
  EE=$(printf "%03d" "$E")
  CKPT="$EPOCH_SWEEP_DIR/W_epoch_${EE}.pt"

  if [[ ! -f "$CKPT" && "$WAIT_FOR_CHECKPOINTS" == "1" ]]; then
    echo "[WAIT] $CKPT"
    waited=0
    while [[ ! -f "$CKPT" ]]; do
      sleep "$WAIT_POLL_SECONDS"
      waited=$((waited + WAIT_POLL_SECONDS))
      if [[ "$WAIT_MAX_SECONDS" -gt 0 && "$waited" -ge "$WAIT_MAX_SECONDS" ]]; then
        echo "[ERROR] timeout waiting for $CKPT"
        exit 4
      fi
    done
  fi

  if [[ ! -f "$CKPT" ]]; then
    echo "[SKIP] missing $CKPT"
    continue
  fi

  PROJ="paper_epochsweep_${TAG}_epoch${EE}"
  WEIGHT_OUT="weights/${PROJ}.pth"
  METRICS="$RUN_ROOT/epoch_sweep/epoch_${EE}_metrics.json"
  EVAL_OUT="$RUN_ROOT/epoch_sweep/eval_epoch_${EE}"

  echo "[EPOCH $EE] bake"
  CUDA_VISIBLE_DEVICES="$GPU" python bake_predobj_relproto_w_into_projector_final.py \
    --project_root . \
    --projector "$CLIP_WEIGHT" \
    --w_checkpoint "$CKPT" \
    --text_bank "$CLIP_PART_BANK" \
    --model_config "$CLIP_CFG" \
    --output "$WEIGHT_OUT" \
    --device cuda \
    --overwrite

  echo "[EPOCH $EE] full-image PP-116 eval, PAMR=false"
  CUDA_VISIBLE_DEVICES="$GPU" PYTHONUNBUFFERED=1 \
  python -m torch.distributed.run --nproc_per_node=1 --master_port="$((35000 + E))" \
    "$SUITE/eval_with_raw_text_and_metrics.py" \
      --metrics_json "$METRICS" \
      --eval \
      --output "$EVAL_OUT" \
      --eval_cfg src/open_vocabulary_segmentation/configs/voc116_part/dinotext_voc116_part_vitb_mlp_infonce.yml \
      --eval_base_cfg src/open_vocabulary_segmentation/configs/voc116_part/eval_voc116_part.yml \
      --opts \
        "model.proj_name=${PROJ}" \
        evaluate.pamr=false \
        evaluate.bg_thresh=0.4

done

python "$SUITE/summarize_epoch_sweep.py" \
  --root "$RUN_ROOT/epoch_sweep" \
  --output_csv "$RUN_ROOT/epoch_sweep_001_100.csv"

echo "[DONE] epoch sweep CSV: $RUN_ROOT/epoch_sweep_001_100.csv"
