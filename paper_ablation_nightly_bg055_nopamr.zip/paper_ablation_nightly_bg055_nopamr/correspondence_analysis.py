#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, sys
from pathlib import Path
import numpy as np
import torch
import torch.nn.functional as F
import yaml

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
sys.path.insert(0,str(ROOT)); sys.path.insert(0,str(HERE))
from text_bank_utils import load_raw_bank, tload

def load_projector(cfg_path, weight_path, device):
    import importlib
    cfg=yaml.safe_load(Path(cfg_path).read_text())["model"]
    cls=getattr(importlib.import_module("src.model"),cfg.get("model_class","ProjectionLayer"))
    m=cls.from_config(cfg)
    obj=tload(weight_path)
    if isinstance(obj,dict):
        for k in ("state_dict","model_state_dict","projector_state_dict"):
            if k in obj and isinstance(obj[k],dict): obj=obj[k]; break
    s={str(k):v for k,v in obj.items() if torch.is_tensor(v)}
    if s and all(k.startswith("module.") for k in s): s={k[7:]:v for k,v in s.items()}
    m.load_state_dict(s,strict=True); m=m.to(device).eval()
    return m

@torch.inference_mode()
def projected_text(raw,m,device,W=None):
    out=[]
    for s in range(0,len(raw),128):
        out.append(m.project_clip_txt(raw[s:s+128].to(device).float()).cpu().float())
    z=F.normalize(torch.cat(out),dim=-1)
    if W is not None: z=F.normalize(z@W.float().cpu(),dim=-1)
    return z

def metrics(text,visual,available,names):
    ids=torch.where(available.bool())[0]
    t=F.normalize(text[ids].float(),dim=-1)
    v=F.normalize(visual[ids].float(),dim=-1)
    sim=t@v.T
    pred=sim.argmax(1)
    correct=torch.arange(len(ids))
    pm=float((pred==correct).float().mean())
    diag=sim.diag()
    wrong=sim.clone(); wrong[correct,correct]=-torch.inf
    margin=diag-wrong.max(1).values
    # within-object counterpart
    parent=[names[int(i)].split("'s ",1)[0] for i in ids.tolist()]
    w_hits=[];w_margin=[]
    for i,p in enumerate(parent):
        js=[j for j,q in enumerate(parent) if q==p]
        if len(js)<2: continue
        vals=sim[i,js]
        local_correct=js.index(i)
        w_hits.append(float(vals.argmax().item()==local_correct))
        tmp=vals.clone(); tmp[local_correct]=-torch.inf
        w_margin.append(float(vals[local_correct]-tmp.max()))
    return {
        "available_parts":int(len(ids)),
        "PartMatch@1_global":pm,
        "CorrespondenceMargin_global":float(margin.mean()),
        "PartMatch@1_within_object":float(np.mean(w_hits)) if w_hits else None,
        "CorrespondenceMargin_within_object":float(np.mean(w_margin)) if w_margin else None,
        "mean_correct_similarity":float(diag.mean()),
    }, ids, sim

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--text_bank",required=True)
    p.add_argument("--model_config",required=True)
    p.add_argument("--projector",required=True)
    p.add_argument("--w_checkpoint",default="")
    p.add_argument("--gt_visual_cache",required=True)
    p.add_argument("--label",required=True)
    p.add_argument("--out_dir",required=True)
    p.add_argument("--device",default="cuda")
    a=p.parse_args()
    out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    raw,names,_=load_raw_bank(a.text_bank,expected_rows=116)
    gt=tload(a.gt_visual_cache)
    gt_names=list(gt.get("part_classes",[]))
    if gt_names and gt_names!=names: raise ValueError("GT visual cache taxonomy mismatch")
    visual=torch.as_tensor(gt["crop_balanced_prototypes"]).float()
    avail=torch.as_tensor(gt["available"]).bool()
    m=load_projector(a.model_config,a.projector,a.device)
    W=None
    if a.w_checkpoint:
        ck=tload(a.w_checkpoint); W=torch.as_tensor(ck["W"]).float()
    z=projected_text(raw,m,a.device,W)
    met,ids,sim=metrics(z,visual,avail,names)
    payload={"label":a.label,**met}
    (out/f"{a.label}.json").write_text(json.dumps(payload,indent=2)+"\n")
    np.savez_compressed(
        out/f"{a.label}_matrix.npz",
        similarity=sim.numpy(),
        global_part_ids=ids.numpy(),
        part_names=np.array([names[int(i)] for i in ids.tolist()],dtype=object),
    )
    try:
        import matplotlib.pyplot as plt
        fig=plt.figure(figsize=(10,9))
        ax=fig.add_subplot(111)
        im=ax.imshow(sim.numpy(),aspect="auto")
        ax.set_title(a.label)
        ax.set_xlabel("GT visual part prototype")
        ax.set_ylabel("text part prototype")
        fig.colorbar(im,ax=ax)
        fig.tight_layout()
        fig.savefig(out/f"{a.label}_matrix.png",dpi=180)
        plt.close(fig)
    except Exception as e:
        print("[warn] matrix PNG skipped:",e)
    print(json.dumps(payload,indent=2))

if __name__=="__main__": main()
