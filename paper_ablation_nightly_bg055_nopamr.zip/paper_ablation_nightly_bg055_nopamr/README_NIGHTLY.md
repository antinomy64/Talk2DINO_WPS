# Paper Ablation Nightly Suite — bg055 / final no-PAMR

This directory is an **add-only** experiment package for the current Talk2DINO_WPS repository.
It does **not edit any tracked repository file**. `repo_guard.py` snapshots tracked files before the suite and verifies them after completion.

## Fixed protocol

Training-cache protocol:
- PP-116 training images
- predicted object foreground from the frozen object-level Talk2DINO projector
- `bg_thresh = 0.55`
- PAMR **enabled** for predicted-object foreground generation
- crop expand ratio 1.2
- 448 crop / 224 stride / DINOv2 ViT-B/14 registers

Final segmentation evaluation protocol:
- PP-116 full-image inference
- 116 semantic part classes
- GT background / unlabeled pixels ignored (255)
- **PAMR disabled for every final segmentation evaluation**

This distinction is intentional: PAMR is used to construct the predicted-object training cache, but **never** as final part-segmentation post-processing in this suite.

## Fixed existing artifacts

CLIP:
- PredObj cache: `feature/pascalpart116_predobj_clip_struct/train_predobj_cropaug_bg055_reproduce.pth`
- part text bank: `feature/pascalpart116_clip_text/pascalpart116_clip_vitb16_subimagenet_raw_reproduce.pt`
- object-level projector: `weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth`

LLaMA3:
- part text bank: `feature/pascalpart116_llama3_text/pascalpart116_llama3_raw.pt`
- object-level projector: `weights/vitb_mlp_infonce_llama4096_overnight_v1_coco2014_llama3_caption.pth`
- PredObj cache: rebuilt by this suite at bg=0.55 + PAMR and stored under `feature/paper_ablation_nightly_bg055_nopamr/`

100-epoch main run for the final sweep:
- `final_exp/relproto_alignment/main_seed123_bg055_L4/W_epoch_001.pt`
- ...
- `final_exp/relproto_alignment/main_seed123_bg055_L4/W_epoch_100.pt`

## Experiments covered

### A. CLIP component ablation

Three seeds by default: `123 456 789`.

1. Talk2DINO baseline — no part-level adaptation.
2. Absolute + Linear — absolute top-1 evidence, unconstrained shared linear W, `L=1`.
3. Relative + Linear — relative evidence, unconstrained shared linear W, default `L=4`.
4. Relative + Orthogonal — relative evidence, shared orthogonal W, default `L=4`.

Output table:
- `table_clip_component_ablation.csv`

### B. Relative Visual Prototype support-size ablation

Relative + Orthogonal with:
- `L = 1, 2, 4, 6, 8`

Three seeds by default. `L=4` reuses the component-ablation run.

Output table:
- `table_clip_relproto_L_ablation.csv`

### C. Part-level correspondence analysis

Analysis-only GT visual prototypes are read from:
- `feature/pascalpart116_gt_visual_structure/gt_dinov2_vitb14reg_train_objcrop_x1p2.pt`

The suite evaluates:
- Talk2DINO baseline once
- Relative + Linear at **every training epoch** for each seed
- Relative + Orthogonal at **every training epoch** for each seed

Metrics:
- PartMatch@1 global
- Correspondence Margin global
- within-object counterparts
- mean correct similarity

Output:
- `correspondence_epoch_curves.csv`
- individual JSON/NPZ files under `correspondence/`

If the GT visual cache is absent, this analysis is skipped without affecting other experiments.

### D. LLaMA3 robustness

The suite first creates a 20-object LLaMA3 raw object bank if absent, then regenerates the LLaMA3 predicted-object crop cache at **bg=0.55 + PAMR** using the supplied LLaMA object-level projector.

It then runs the paper's four rows:
1. Talk2DINO baseline
2. Absolute + Linear
3. Relative + Linear
4. Relative + Orthogonal

Three seeds by default for adapted variants.

Output table:
- `table_llama3_robustness.csv`

The suite-local projector YAML is:
- `paper_ablation_nightly_bg055_nopamr/configs/vitb_mlp_infonce_llama4096_overnight_v1.yaml`

The current repository must already support the LLaMA projector class/name used by the supplied checkpoint, as in the previous overnight suite.

### E. Extra requested epoch 001–100 mIoU sweep

Executed **last**.

For every:
- `W_epoch_001.pt`
- `W_epoch_002.pt`
- ...
- `W_epoch_100.pt`

it performs:
1. bake W into `vitb_mlp_infonce_coco2014_reproduce_clean.pth` using the repository's `bake_predobj_relproto_w_into_projector_final.py`;
2. PP-116 full-image evaluation with `evaluate.pamr=false`;
3. save mIoU, mACC and aACC.

Output:
- `epoch_sweep_001_100.csv`

By default, if a future epoch checkpoint does not exist yet, the sweep waits for it. Set:

```bash
WAIT_FOR_CHECKPOINTS=0
```

to skip missing checkpoints instead.

## Run

Unzip/copy this whole directory into the repository root so that the layout is:

```text
Talk2DINO_WPS/
├── paper_ablation_nightly_bg055_nopamr/
├── extract_predobj_cropaug.py
├── train_relproto_alignemt.py
├── bake_predobj_relproto_w_into_projector_final.py
├── configs/
├── feature/
├── weights/
└── src/
```

Then:

```bash
chmod +x paper_ablation_nightly_bg055_nopamr/run_all.sh
GPU=0 bash paper_ablation_nightly_bg055_nopamr/run_all.sh
```

Common overrides:

```bash
GPU=1 SEEDS="123 456 789" EPOCHS_W=10 \
  bash paper_ablation_nightly_bg055_nopamr/run_all.sh
```

Run only the epoch sweep:

```bash
RUN_CLIP=0 RUN_LLAMA=0 RUN_CORRESPONDENCE=0 RUN_EPOCH_SWEEP=1 \
  GPU=0 bash paper_ablation_nightly_bg055_nopamr/run_all.sh
```

Skip epoch sweep:

```bash
RUN_EPOCH_SWEEP=0 GPU=0 \
  bash paper_ablation_nightly_bg055_nopamr/run_all.sh
```

## Output layout

Each invocation gets a timestamped run tag.

```text
output/paper_ablation_nightly_bg055_nopamr/<RUN_TAG>/
├── all_eval_metrics.csv
├── table_clip_component_ablation.csv
├── table_clip_relproto_L_ablation.csv
├── table_llama3_robustness.csv
├── correspondence_epoch_curves.csv
├── epoch_sweep_001_100.csv
├── FINAL_SUMMARY.json
├── correspondence/
├── epoch_sweep/
└── logs/

final_exp/paper_ablation_nightly_bg055_nopamr/<RUN_TAG>/
└── ... W-training runs ...

feature/paper_ablation_nightly_bg055_nopamr/
├── voc20_llama3_object_raw.pt
└── pascalpart116_predobj_llama3_bg055.pth
```

Baked evaluation projectors are written as uniquely prefixed files under `weights/` so they do not overwrite supplied projectors.

## Notes

- The suite deliberately does not regenerate the supplied CLIP part bank or CLIP PredObj cache.
- The CLIP reproduce text bank has already been verified feature-wise identical to the earlier bank; this suite uses the supplied reproduce path explicitly.
- The LLaMA PredObj cache is regenerated because the requested protocol is bg=0.55 + PAMR.
- Final segmentation PAMR is disabled everywhere in this package, including the 001–100 epoch sweep.
- No repository source file is edited.
