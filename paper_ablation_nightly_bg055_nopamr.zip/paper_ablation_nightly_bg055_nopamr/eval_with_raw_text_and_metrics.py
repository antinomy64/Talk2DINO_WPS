#!/usr/bin/env python3
"""
Wrapper around the repository OV segmentation evaluator.

Features:
1) optional --raw_text_bank: replace CLIP-built class text features by a raw
   precomputed bank (e.g. LLaMA3) projected by the model's projector;
2) --metrics_json: save the full MMSeg metric dict, including mIoU/mAcc/aAcc,
   instead of only the repository's scalar segmentation_results mIoU.

No repository source file is modified.
"""
from __future__ import annotations
import argparse, json, os, sys
from pathlib import Path
import torch
import torch.nn.functional as F

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
OVROOT = ROOT / "src" / "open_vocabulary_segmentation"
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))
sys.path.insert(0, str(OVROOT))
os.chdir(ROOT)

from text_bank_utils import load_raw_bank, jsonable

def main():
    p = argparse.ArgumentParser(add_help=False)
    p.add_argument("--raw_text_bank", default="")
    p.add_argument("--metrics_json", required=True)
    known, rest = p.parse_known_args()
    sys.argv = [sys.argv[0]] + rest
    metrics_path = Path(known.metrics_json).resolve()
    metrics_path.parent.mkdir(parents=True, exist_ok=True)

    if known.raw_text_bank:
        raw, bank_names, _ = load_raw_bank(known.raw_text_bank)
        name_to_row = {n: i for i, n in enumerate(bank_names)}
        if len(name_to_row) != len(bank_names):
            raise ValueError("duplicate names in raw text bank")

        from models.dinotext.dinotext import DINOText

        def patched_tokens(self, template_set, classnames):
            req = [str(x) for x in classnames]
            missing = [x for x in req if x not in name_to_row]
            if missing:
                raise ValueError(
                    "evaluation taxonomy has names absent from raw bank: "
                    + repr(missing[:20])
                )
            return ("__PRECOMPUTED_RAW_TEXT_BANK__", tuple(req))

        @torch.no_grad()
        def patched_embedding(self, payload):
            if not (
                isinstance(payload, tuple)
                and len(payload) == 2
                and payload[0] == "__PRECOMPUTED_RAW_TEXT_BANK__"
            ):
                raise TypeError("unexpected text payload")
            req = list(payload[1])
            idx = torch.tensor(
                [name_to_row[x] for x in req],
                dtype=torch.long,
            )
            rows = raw.index_select(0, idx)
            expected_dim = int(self.proj.linear_layer.in_features)
            if rows.shape[1] != expected_dim:
                raise ValueError(
                    f"raw text dim={rows.shape[1]} != projector input={expected_dim}"
                )
            dev = next(self.proj.parameters()).device
            z = self.proj.project_clip_txt(rows.to(dev, dtype=torch.float32))
            return F.normalize(z.float(), dim=-1)

        DINOText.build_dataset_class_tokens = patched_tokens
        DINOText.build_text_embedding = patched_embedding
        print("[nightly] evaluator semantic text source: PRECOMPUTED RAW BANK")
        print("[nightly] bank:", Path(known.raw_text_bank).resolve())

    import main as ovmain
    original_validate = ovmain.validate_seg

    def wrapped_validate(*args, **kwargs):
        miou, metric = original_validate(*args, **kwargs)
        try:
            rank = 0
            if torch.distributed.is_available() and torch.distributed.is_initialized():
                rank = torch.distributed.get_rank()
            if rank == 0 and metric and metric[0] is not None:
                payload = {
                    "miou_percent_from_main": float(miou),
                    "metric": jsonable(metric[0]),
                }
                metrics_path.write_text(
                    json.dumps(payload, indent=2, ensure_ascii=False) + "\n",
                    encoding="utf-8",
                )
                print("[nightly] full metric saved:", metrics_path)
        finally:
            pass
        return miou, metric

    ovmain.validate_seg = wrapped_validate
    ovmain.main()

if __name__ == "__main__":
    main()
