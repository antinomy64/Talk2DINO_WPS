#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, re
from pathlib import Path
from collections import defaultdict
import numpy as np


def loadj(p):
    return json.loads(Path(p).read_text())


def metric_pct(d, key):
    m = d.get('metric', {})
    v = m.get(key)
    if v is None:
        return None
    v = float(v)
    return v * 100.0 if abs(v) <= 1.5 else v


def write_csv(path, rows):
    if not rows:
        return
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fields = list(dict.fromkeys(k for r in rows for k in r.keys()))
    with path.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)


def aggregate(rows, label, prefix):
    vals = [r for r in rows if r['run'].startswith(prefix)]
    if not vals:
        return None
    mi = [r['mIoU'] for r in vals if r['mIoU'] is not None]
    ma = [r['mACC'] for r in vals if r['mACC'] is not None]
    return {
        'variant': label,
        'n': len(mi),
        'mIoU_mean': float(np.mean(mi)) if mi else None,
        'mIoU_std': float(np.std(mi, ddof=1)) if len(mi)>1 else (0.0 if mi else None),
        'mACC_mean': float(np.mean(ma)) if ma else None,
        'mACC_std': float(np.std(ma, ddof=1)) if len(ma)>1 else (0.0 if ma else None),
    }


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--run_root', required=True)
    a = p.parse_args()
    root = Path(a.run_root)

    rows = []
    # Top-level paper experiments only. Epoch sweep has its own CSV.
    for mp in sorted(root.glob('*_metrics.json')):
        d = loadj(mp)
        stem = mp.stem.replace('_metrics','')
        rows.append({
            'run': stem,
            'mIoU': metric_pct(d,'mIoU') if metric_pct(d,'mIoU') is not None else d.get('miou_percent_from_main'),
            'mACC': metric_pct(d,'mAcc'),
            'aACC': metric_pct(d,'aAcc'),
            'metrics_file': str(mp),
        })
    write_csv(root/'all_eval_metrics.csv', rows)

    clip_component = []
    for label, prefix in [
        ('Talk2DINO', 'clip_baseline'),
        ('Absolute + Linear', 'clip_absolute_linear_seed'),
        ('Relative + Linear', 'clip_relative_linear_seed'),
        ('Relative + Orthogonal', 'clip_relative_orth_L4_seed'),
    ]:
        x = aggregate(rows, label, prefix)
        if x: clip_component.append(x)
    write_csv(root/'table_clip_component_ablation.csv', clip_component)

    lrows = []
    for k in (1,2,4,6,8):
        x = aggregate(rows, f'L={k}', f'clip_relative_orth_L{k}_seed')
        if x:
            x = {'L':k, **{kk:vv for kk,vv in x.items() if kk!='variant'}}
            lrows.append(x)
    write_csv(root/'table_clip_relproto_L_ablation.csv', lrows)

    llama = []
    for label, prefix in [
        ('Talk2DINO', 'llama_baseline'),
        ('Absolute + Linear', 'llama_absolute_linear_seed'),
        ('Relative + Linear', 'llama_relative_linear_seed'),
        ('Relative + Orthogonal', 'llama_relative_orth_L4_seed'),
    ]:
        x = aggregate(rows, label, prefix)
        if x: llama.append(x)
    write_csv(root/'table_llama3_robustness.csv', llama)

    corr = []
    cdir = root/'correspondence'
    if cdir.exists():
        for jp in sorted(cdir.glob('*.json')):
            corr.append(loadj(jp))
    write_csv(root/'correspondence_all_points.csv', corr)

    epoch_rows = []
    ep_csv = root/'epoch_sweep_001_100.csv'
    if ep_csv.exists():
        with ep_csv.open() as f:
            epoch_rows = list(csv.DictReader(f))

    summary = {
        'protocol': {
            'predobj_bg_thresh': 0.55,
            'predobj_pamr': True,
            'final_eval_pamr': False,
            'pp116_background': 'ignored/255',
            'full_image_eval': True,
        },
        'eval_rows': rows,
        'clip_component_ablation': clip_component,
        'clip_relproto_L_ablation': lrows,
        'llama3_robustness': llama,
        'correspondence_points': len(corr),
        'epoch_sweep_rows': len(epoch_rows),
    }
    (root/'FINAL_SUMMARY.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
