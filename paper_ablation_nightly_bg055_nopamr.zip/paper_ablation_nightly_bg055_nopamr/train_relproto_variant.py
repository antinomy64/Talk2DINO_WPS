#!/usr/bin/env python3
"""
Generic RelProto alignment ablation trainer.

It imports the current repository train_relproto_alignemt.py for the cache
contract, frozen projector loader, current relative selector and diagnostics,
but removes the hard-coded [116,512] CLIP bank assumption.

Supported selectors:
  absolute          absolute cosine; own row argmax; optional positive extras
  relative          repository's current relative selector (Ours)
  shuffled_relative wrong-relation control: selector queries are deterministically
                    permuted inside each annotation, while the optimization row
                    retains the correct semantic identity

Supported mappings:
  linear            one shared unconstrained 768x768 matrix
  orthogonal        same matrix/identity init/Adam + repository SVD retraction

No existing repository file is changed.
"""
from __future__ import annotations
import argparse, csv, hashlib, json, os, sys, time
from collections import defaultdict
from pathlib import Path
from typing import Any
import numpy as np
import torch
from torch.utils.data import DataLoader
from tqdm import tqdm

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(HERE))

import train_relproto_alignemt as base
from text_bank_utils import load_raw_bank, sha256

def atomic_save(obj, path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    torch.save(obj, tmp)
    os.replace(tmp, path)

def dump_json(obj, path):
    Path(path).write_text(json.dumps(obj, indent=2, default=str) + "\n")

def write_csv(rows, path):
    if not rows:
        return
    fields = list(dict.fromkeys(k for r in rows for k in r))
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)

@torch.inference_mode()
def generic_project(raw, projector, device, batch_size=128):
    out = []
    for s in range(0, raw.shape[0], batch_size):
        y = projector.project_clip_txt(raw[s:s+batch_size].to(device, dtype=torch.float32))
        if y.ndim != 2 or y.shape[1] != 768:
            raise ValueError(f"projector output shape={tuple(y.shape)}")
        out.append(y.float().cpu())
    z = torch.cat(out, 0)
    if z.shape != (116, 768):
        raise ValueError(f"expected [116,768], got {tuple(z.shape)}")
    return base.normalize_last(z).contiguous()

def absolute_proto(current_text, patch_tokens, foreground, max_patches):
    n, k, d = current_text.shape
    with torch.no_grad():
        q = base.normalize_last(current_text.detach())
        absolute = torch.bmm(q, patch_tokens.transpose(1,2))
        scores = absolute.masked_fill(~foreground[:,None,:], -torch.inf)
        anchors = scores.argmax(2)
        anchor_scores = scores.gather(2, anchors[:,:,None]).squeeze(2)

        support = torch.full(
            (n,k,max_patches), -1, dtype=torch.long, device=current_text.device
        )
        support[:,:,0] = anchors
        if max_patches > 1:
            eligible = scores.clone()
            eligible.scatter_(2, anchors[:,:,None], -torch.inf)
            eligible.masked_fill_(eligible <= 0.0, -torch.inf)
            topv, topi = torch.topk(
                eligible, k=max_patches-1, dim=2, largest=True, sorted=True
            )
            support[:,:,1:] = torch.where(
                torch.isfinite(topv), topi, torch.full_like(topi, -1)
            )
        valid = support >= 0
        counts = valid.sum(2)
        bi = torch.arange(n, device=current_text.device)[:,None,None]
        gathered = patch_tokens[bi, support.clamp_min(0)]
        means = (gathered * valid[:,:,:,None]).sum(2) / counts[:,:,None]
        proto = base.normalize_last(means)
        anchor_feat = patch_tokens[
            torch.arange(n, device=current_text.device)[:,None], anchors
        ]
        proto = torch.where((counts==1)[:,:,None], anchor_feat, proto)

        coll, excess = [], []
        for row in anchors:
            u = int(torch.unique(row).numel()); kk = int(row.numel())
            coll.append(1.0 if u < kk else 0.0)
            excess.append(float(kk-u))
        return {
            "prototypes": proto.detach(),
            "prototype_counts": counts.detach(),
            "anchor_relative_scores": anchor_scores.detach(),  # same stats slot
            "collision_annotation": torch.tensor(coll, device=current_text.device),
            "collision_excess": torch.tensor(excess, device=current_text.device),
        }

def deterministic_roll(ex, k, seed):
    if k <= 1:
        return 0
    msg = f"{seed}|{ex.image_id}|{ex.ann_id}|{ex.class_name}".encode()
    h = int(hashlib.sha256(msg).hexdigest()[:16], 16)
    return 1 + (h % (k - 1))

def batch_forward(base_bank, W, examples, device, selector, max_patches, shuffle_seed):
    tokens = torch.stack([x.tokens for x in examples]).to(device, dtype=torch.float32)
    fg = torch.stack([x.foreground for x in examples]).to(device, dtype=torch.bool)
    tokens = base.normalize_last(tokens)

    groups = defaultdict(list)
    for i, ex in enumerate(examples):
        groups[int(ex.pids.numel())].append(i)

    losses = [None] * len(examples)
    all_counts, all_anchor, all_coll, all_excess = [], [], [], []

    for k in sorted(groups):
        members = groups[k]
        idx = torch.tensor(members, device=device, dtype=torch.long)
        pids = torch.stack([examples[i].pids for i in members]).to(device)
        current = base.normalize_last(base_bank[pids] @ W)

        if selector == "relative":
            sel = base.build_relproto(
                current.detach(), tokens[idx], fg[idx], max_patches=max_patches
            )
        elif selector == "absolute":
            sel = absolute_proto(
                current.detach(), tokens[idx], fg[idx], max_patches=max_patches
            )
        elif selector == "shuffled_relative":
            wrong = current.detach().clone()
            for local_i, member in enumerate(members):
                shift = deterministic_roll(examples[member], k, shuffle_seed)
                if shift:
                    wrong[local_i] = torch.roll(wrong[local_i], shifts=shift, dims=0)
            sel = base.build_relproto(
                wrong, tokens[idx], fg[idx], max_patches=max_patches
            )
        else:
            raise ValueError(selector)

        target = sel["prototypes"].detach()
        cosine = (current * target).sum(2)
        lv = (1.0 - cosine).mean(1)
        for j, member in enumerate(members):
            losses[member] = lv[j]

        all_counts.append(sel["prototype_counts"].float().reshape(-1))
        all_anchor.append(sel["anchor_relative_scores"].reshape(-1))
        all_coll.append(sel["collision_annotation"].float())
        all_excess.append(sel["collision_excess"].float())

    if any(x is None for x in losses):
        raise AssertionError("unprocessed annotation")
    loss = torch.stack([x for x in losses if x is not None]).mean()
    if not torch.isfinite(loss):
        raise ValueError("nonfinite loss")
    with torch.no_grad():
        counts = torch.cat(all_counts)
        a = torch.cat(all_anchor)
        c = torch.cat(all_coll)
        e = torch.cat(all_excess)
        stats = {
            "prototype_mean_patch_count": float(counts.mean()),
            "prototype_anchor_only_fraction": float((counts==1).float().mean()),
            "mean_anchor_selector_score": float(a.mean()),
            "anchor_collision_annotation_rate": float(c.mean()),
            "mean_anchor_collision_excess": float(e.mean()),
        }
    return loss, stats

def build_parser():
    p = argparse.ArgumentParser(allow_abbrev=False)
    p.add_argument("--project_root", default=".")
    p.add_argument("--train_dataset", required=True)
    p.add_argument("--text_bank", required=True)
    p.add_argument("--model_config", required=True)
    p.add_argument("--weights", required=True)
    p.add_argument("--out_dir", required=True)
    p.add_argument("--selector", choices=["absolute","relative","shuffled_relative"], required=True)
    p.add_argument("--mapping", choices=["linear","orthogonal"], required=True)
    p.add_argument("--prototype_max_patches", type=int, default=4)
    p.add_argument("--epochs", type=int, default=10)
    p.add_argument("--batch_size", type=int, default=16)
    p.add_argument("--lr", type=float, default=1e-3)
    p.add_argument("--seed", type=int, default=123)
    p.add_argument("--shuffle_seed", type=int, default=99173)
    p.add_argument("--device", default="cuda")
    p.add_argument("--num_workers", type=int, default=0)
    p.add_argument("--expected_bg_thresh", type=float, default=0.55)
    p.add_argument("--require_pamr", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--require_cache_projector_match", action=argparse.BooleanOptionalAction, default=True)
    p.add_argument("--feature_name", default="cropaug_patch_tokens")
    p.add_argument("--foreground_key", default="pred_obj_mask_patch")
    p.add_argument("--part_id_key", default="part_category_id")
    p.add_argument("--part_name_key", default="part_class_name")
    p.add_argument("--max_annotations", type=int, default=0)
    return p

def main():
    args = build_parser().parse_args()
    root = Path(args.project_root).resolve()
    if str(root) not in sys.path:
        sys.path.insert(0, str(root))
    dev = torch.device(args.device)
    out = (root / args.out_dir).resolve()
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f"refusing to mix run: {out}")
    out.mkdir(parents=True, exist_ok=True)

    bank_path = (root / args.text_bank).resolve()
    cfg_path = (root / args.model_config).resolve()
    weight_path = (root / args.weights).resolve()
    data_path = (root / args.train_dataset).resolve()
    for p in (bank_path,cfg_path,weight_path,data_path):
        if not p.is_file():
            raise FileNotFoundError(p)

    raw, names, bank_meta = load_raw_bank(bank_path, expected_rows=116)
    projector, proj_info = base.load_frozen_projector(
        project_root=root, config_path=cfg_path, weight_path=weight_path, device=dev
    )
    expected_dim = int(projector.linear_layer.in_features)
    if raw.shape[1] != expected_dim:
        raise ValueError(
            f"raw bank dim={raw.shape[1]} but projector input dim={expected_dim}"
        )
    projected = generic_project(raw, projector, dev)
    del projector

    examples, preflight = base.prepare_examples(
        data_path,
        text_names=names,
        patch_key=args.feature_name,
        foreground_key=args.foreground_key,
        part_id_key=args.part_id_key,
        part_name_key=args.part_name_key,
        max_annotations=args.max_annotations,
        expected_bg_thresh=args.expected_bg_thresh,
        require_pamr=args.require_pamr,
        projector_weight_sha256=proj_info["weights_sha256"],
        require_cache_projector_match=args.require_cache_projector_match,
    )
    rows = preflight.pop("rows")
    base.write_csv(rows, out/"training_samples.csv")
    dump_json(vars(args), out/"args.json")
    dump_json(
        {
            "path": str(bank_path),
            "sha256": sha256(bank_path),
            "raw_shape": list(raw.shape),
            "class_names": names,
            "normalized": False,
            "projected_shape": list(projected.shape),
        },
        out/"text_bank.json",
    )
    dump_json(proj_info, out/"projector.json")
    dump_json(preflight, out/"preflight.json")

    base.set_seed(args.seed)
    bank = projected.to(dev).detach()
    W = torch.nn.Parameter(torch.eye(768, device=dev, dtype=torch.float32))
    opt = torch.optim.Adam([W], lr=args.lr, weight_decay=0.0)
    ds = base.PredObjDataset(examples)
    loader = DataLoader(
        ds, batch_size=args.batch_size, shuffle=True, num_workers=args.num_workers,
        pin_memory=(dev.type=="cuda"), collate_fn=base.collate_examples, drop_last=False
    )
    history = []
    step = 0
    print("="*72)
    print("GENERIC RELPROTO ABLATION")
    print("selector :", args.selector)
    print("mapping  :", args.mapping)
    print("raw bank :", tuple(raw.shape), bank_path)
    print("projector:", weight_path)
    print("examples :", len(examples))
    print("="*72)

    for epoch in range(1,args.epochs+1):
        t0=time.time()
        ls=[]; gs=[]; pc=[]; ao=[]; ars=[]; ca=[]; ce=[]
        bar=tqdm(loader, desc=f"{args.selector}/{args.mapping} {epoch:02d}/{args.epochs:02d}")
        for batch in bar:
            opt.zero_grad(set_to_none=True)
            loss, st = batch_forward(
                bank, W, batch, dev, args.selector,
                args.prototype_max_patches, args.shuffle_seed
            )
            loss.backward()
            if W.grad is None or not torch.isfinite(W.grad).all():
                raise ValueError("invalid W gradient")
            gs.append(float(W.grad.norm()))
            opt.step()
            if args.mapping=="orthogonal":
                base.orthogonal_retract_(W)
            if not torch.isfinite(W).all():
                raise ValueError("nonfinite transform")
            step += 1
            ls.append(float(loss.detach()))
            pc.append(st["prototype_mean_patch_count"])
            ao.append(st["prototype_anchor_only_fraction"])
            ars.append(st["mean_anchor_selector_score"])
            ca.append(st["anchor_collision_annotation_rate"])
            ce.append(st["mean_anchor_collision_excess"])
            bar.set_postfix(loss=f"{ls[-1]:.4f}", proto=f"{pc[-1]:.2f}")

        ms=base.matrix_stats(W.detach(),bank)
        with torch.no_grad():
            sv=torch.linalg.svdvals(W.detach())
            cond=float((sv.max()/sv.min().clamp_min(1e-12)).item())
        row={
            "epoch":epoch,
            "selector":args.selector,
            "mapping":args.mapping,
            "mean_loss":float(np.mean(ls)),
            "mean_grad_norm":float(np.mean(gs)),
            "prototype_mean_patch_count":float(np.mean(pc)),
            "prototype_anchor_only_fraction":float(np.mean(ao)),
            "mean_anchor_selector_score":float(np.mean(ars)),
            "anchor_collision_annotation_rate":float(np.mean(ca)),
            "mean_anchor_collision_excess":float(np.mean(ce)),
            "condition_number":cond,
            "seconds":time.time()-t0,
            **ms,
        }
        history.append(row)
        write_csv(history,out/"training_history.csv")
        payload={
            "format":"nightly_generic_relproto_variant_v1",
            "W":W.detach().cpu().clone(),
            "optimizer_state_dict":opt.state_dict(),
            "epoch":epoch,
            "global_step":step,
            "history":history,
            "args":vars(args),
            "selector":args.selector,
            "mapping":args.mapping,
            "raw_text_bank":str(bank_path),
            "raw_text_bank_sha256":sha256(bank_path),
            "raw_text_dim":int(raw.shape[1]),
            "projector":proj_info,
            "preflight":preflight,
            "shuffled_relation_definition":(
                "fixed non-identity within-annotation cyclic permutation of selector "
                "queries; optimization rows retain correct semantic identity"
                if args.selector=="shuffled_relative" else None
            ),
        }
        atomic_save(payload,out/f"W_epoch_{epoch:03d}.pt")
        atomic_save(payload,out/"W_last.pt")
        print(
            f"[epoch] {epoch}/{args.epochs} loss={row['mean_loss']:.6f} "
            f"struct_delta={row['text_cosine_structure_max_abs']:.3e} "
            f"orth_err={row['orthogonality_max_abs']:.3e} cond={cond:.3f}"
        )
    dump_json(
        {
            "status":"completed",
            "selector":args.selector,
            "mapping":args.mapping,
            "checkpoint":"W_last.pt",
            "history":history,
        },
        out/"summary.json",
    )

if __name__=="__main__":
    main()
