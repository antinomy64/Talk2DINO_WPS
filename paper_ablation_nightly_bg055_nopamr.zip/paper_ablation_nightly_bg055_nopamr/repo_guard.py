#!/usr/bin/env python3
from __future__ import annotations
import argparse, hashlib, json, subprocess
from pathlib import Path

def cmd(*args):
    return subprocess.check_output(args,text=True).strip()

def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(8<<20),b""): h.update(b)
    return h.hexdigest()

def snapshot(root):
    root=Path(root).resolve()
    files=cmd("git","-C",str(root),"ls-files").splitlines()
    return {f:sha(root/f) for f in files if (root/f).is_file()}

def main():
    p=argparse.ArgumentParser()
    p.add_argument("mode",choices=["snapshot","verify"])
    p.add_argument("--repo",default=".")
    p.add_argument("--state",required=True)
    a=p.parse_args()
    state=Path(a.state)
    now=snapshot(a.repo)
    if a.mode=="snapshot":
        state.parent.mkdir(parents=True,exist_ok=True)
        state.write_text(json.dumps(now,sort_keys=True,indent=2)+"\n")
        print("[repo-guard] tracked-file snapshot:",len(now))
    else:
        old=json.loads(state.read_text())
        changed=[k for k in sorted(set(old)|set(now)) if old.get(k)!=now.get(k)]
        if changed:
            raise SystemExit(
                "[repo-guard] ERROR: tracked repository files changed during suite:\n"
                + "\n".join(changed[:100])
            )
        print("[repo-guard] PASS: no tracked repository file was modified")

if __name__=="__main__": main()
