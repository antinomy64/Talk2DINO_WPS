#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, re
from collections import defaultdict
from pathlib import Path
import numpy as np


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--input_dir', required=True)
    p.add_argument('--output_csv', required=True)
    a = p.parse_args()
    root = Path(a.input_dir)
    groups = defaultdict(list)
    baseline = None
    pat = re.compile(r'^(Linear|Ours)_seed(\d+)_epoch(\d+)$')
    for jp in root.glob('*.json'):
        d = json.loads(jp.read_text())
        label = d.get('label', jp.stem)
        if label == 'Talk2DINO_Part':
            baseline = d
            continue
        m = pat.match(label)
        if not m:
            continue
        method, seed, epoch = m.group(1), int(m.group(2)), int(m.group(3))
        d['_seed'] = seed; d['_epoch'] = epoch; d['_method'] = method
        groups[(method, epoch)].append(d)

    metric_keys = [
        'PartMatch@1_global',
        'CorrespondenceMargin_global',
        'PartMatch@1_within_object',
        'CorrespondenceMargin_within_object',
        'mean_correct_similarity',
    ]
    rows = []
    if baseline is not None:
        row = {'method':'Talk2DINO', 'epoch':0, 'n':1}
        for k in metric_keys:
            row[k+'_mean'] = baseline.get(k)
            row[k+'_std'] = 0.0 if baseline.get(k) is not None else None
        rows.append(row)

    for (method, epoch), vals in sorted(groups.items(), key=lambda x: (x[0][1], x[0][0])):
        row = {'method':method, 'epoch':epoch, 'n':len(vals)}
        for k in metric_keys:
            arr = [float(v[k]) for v in vals if v.get(k) is not None]
            row[k+'_mean'] = float(np.mean(arr)) if arr else None
            row[k+'_std'] = float(np.std(arr, ddof=1)) if len(arr)>1 else (0.0 if arr else None)
        rows.append(row)

    out = Path(a.output_csv); out.parent.mkdir(parents=True, exist_ok=True)
    if rows:
        fields = list(rows[0].keys())
        with out.open('w', newline='') as f:
            w = csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
    print('wrote', out, 'rows=', len(rows))

if __name__ == '__main__':
    main()
