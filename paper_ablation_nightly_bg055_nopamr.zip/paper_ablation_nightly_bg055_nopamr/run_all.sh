#!/usr/bin/env bash
set -euo pipefail
export PYTHONDONTWRITEBYTECODE=1

# Paper ablation + analysis nightly suite.
# IMPORTANT: this suite NEVER edits tracked repository files.
# It only reads existing repository code/artifacts and writes NEW outputs.
# Final PP-116 segmentation evaluation is ALWAYS PAMR=false.
# Predicted-object cache generation still uses PAMR and bg_thresh=0.55,
# matching the paper's training-cache protocol.

cd "$(git rev-parse --show-toplevel)"
ROOT="$PWD"
SUITE="paper_ablation_nightly_bg055_nopamr"

GPU="${GPU:-0}"
SEEDS="${SEEDS:-123 456 789}"
RUN_TAG="${RUN_TAG:-$(date +%Y%m%d_%H%M%S)}"
EPOCHS_W="${EPOCHS_W:-10}"
LR_W="${LR_W:-1e-3}"
BATCH_W="${BATCH_W:-16}"
BG_THRESH="${BG_THRESH:-0.55}"
RUN_CLIP="${RUN_CLIP:-1}"
RUN_LLAMA="${RUN_LLAMA:-1}"
RUN_CORRESPONDENCE="${RUN_CORRESPONDENCE:-1}"
RUN_EPOCH_SWEEP="${RUN_EPOCH_SWEEP:-1}"

RUN_ROOT="output/${SUITE}/${RUN_TAG}"
TRAIN_ROOT="final_exp/${SUITE}/${RUN_TAG}"
FEATURE_ROOT="feature/${SUITE}"
mkdir -p "$RUN_ROOT/logs" "$RUN_ROOT/correspondence" "$TRAIN_ROOT" "$FEATURE_ROOT" weights

python "$SUITE/repo_guard.py" snapshot --repo . --state "$RUN_ROOT/tracked_files_before.json"

# -----------------------------------------------------------------------------
# Fixed paper artifacts supplied by the user
# -----------------------------------------------------------------------------
CLIP_CFG="configs/vitb_mlp_infonce.yaml"
CLIP_WEIGHT="weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth"
CLIP_PART_BANK="feature/pascalpart116_clip_text/pascalpart116_clip_vitb16_subimagenet_raw_reproduce.pt"
CLIP_CACHE="feature/pascalpart116_predobj_clip_struct/train_predobj_cropaug_bg055_reproduce.pth"

LLAMA_CFG="$SUITE/configs/vitb_mlp_infonce_llama4096_overnight_v1.yaml"
LLAMA_WEIGHT="weights/vitb_mlp_infonce_llama4096_overnight_v1_coco2014_llama3_caption.pth"
LLAMA_PART_BANK="feature/pascalpart116_llama3_text/pascalpart116_llama3_raw.pt"
LLAMA_OBJ_BANK="$FEATURE_ROOT/voc20_llama3_object_raw.pt"
LLAMA_CACHE="$FEATURE_ROOT/pascalpart116_predobj_llama3_bg055.pth"
LLAMA_PROJ_NAME="vitb_mlp_infonce_llama4096_overnight_v1_coco2014_llama3_caption"

IMAGE_ROOT="data/PascalPart116/images/train"
OBJ_ROOT="data/PascalPart116/annotations_detectron2_obj/train"
PART_ROOT="data/PascalPart116/annotations_detectron2_part/train"

GT_VISUAL_CACHE="${GT_VISUAL_CACHE:-feature/pascalpart116_gt_visual_structure/gt_dinov2_vitb14reg_train_objcrop_x1p2.pt}"

# Existing 100-epoch main run used only by the final epoch sweep.
EPOCH_SWEEP_DIR="${EPOCH_SWEEP_DIR:-final_exp/relproto_alignment/main_seed123_bg055_L4}"

for f in "$CLIP_CFG" "$CLIP_WEIGHT" "$CLIP_PART_BANK" "$CLIP_CACHE"; do
  test -f "$f" || { echo "[ERROR] missing $f"; exit 2; }
done

if [[ "$RUN_LLAMA" == "1" ]]; then
  for f in "$LLAMA_CFG" "$LLAMA_WEIGHT" "$LLAMA_PART_BANK"; do
    test -f "$f" || { echo "[ERROR] missing $f"; exit 3; }
  done
fi

echo "============================================================"
echo "PAPER ABLATION NIGHTLY SUITE"
echo "run tag            : $RUN_TAG"
echo "GPU                : $GPU"
echo "seeds              : $SEEDS"
echo "W epochs           : $EPOCHS_W"
echo "PredObj bg_thresh  : $BG_THRESH"
echo "PredObj PAMR       : TRUE"
echo "Final eval PAMR    : FALSE (fixed)"
echo "CLIP cache         : $CLIP_CACHE"
echo "CLIP part bank     : $CLIP_PART_BANK"
echo "LLaMA part bank    : $LLAMA_PART_BANK"
echo "LLaMA projector    : $LLAMA_WEIGHT"
echo "epoch sweep dir    : $EPOCH_SWEEP_DIR"
echo "============================================================"

# -----------------------------------------------------------------------------
# Dense PP-116 evaluation helpers. PAMR is intentionally disabled everywhere.
# -----------------------------------------------------------------------------
eval_clip () {
  local proj="$1"; local label="$2"; local port="$3"
  CUDA_VISIBLE_DEVICES="$GPU" PYTHONUNBUFFERED=1 \
  python -m torch.distributed.run --nproc_per_node=1 --master_port="$port" \
    "$SUITE/eval_with_raw_text_and_metrics.py" \
      --metrics_json "$RUN_ROOT/${label}_metrics.json" \
      --eval \
      --output "$RUN_ROOT/eval_${label}" \
      --eval_cfg src/open_vocabulary_segmentation/configs/voc116_part/dinotext_voc116_part_vitb_mlp_infonce.yml \
      --eval_base_cfg src/open_vocabulary_segmentation/configs/voc116_part/eval_voc116_part.yml \
      --opts \
        "model.proj_name=${proj}" \
        evaluate.pamr=false \
        evaluate.bg_thresh=0.4 \
    2>&1 | tee "$RUN_ROOT/logs/eval_${label}.log"
}

eval_llama () {
  local proj="$1"; local label="$2"; local port="$3"
  CUDA_VISIBLE_DEVICES="$GPU" PYTHONUNBUFFERED=1 \
  python -m torch.distributed.run --nproc_per_node=1 --master_port="$port" \
    "$SUITE/eval_with_raw_text_and_metrics.py" \
      --raw_text_bank "$LLAMA_PART_BANK" \
      --metrics_json "$RUN_ROOT/${label}_metrics.json" \
      --eval \
      --output "$RUN_ROOT/eval_${label}" \
      --eval_cfg src/open_vocabulary_segmentation/configs/voc116_part/dinotext_voc116_part_vitb_mlp_infonce.yml \
      --eval_base_cfg src/open_vocabulary_segmentation/configs/voc116_part/eval_voc116_part.yml \
      --opts \
        "model.proj_class=vitb_mlp_infonce_llama4096_overnight_v1" \
        "model.proj_name=${proj}" \
        evaluate.pamr=false \
        evaluate.bg_thresh=0.4 \
    2>&1 | tee "$RUN_ROOT/logs/eval_${label}.log"
}

# Train one W variant, bake it, and evaluate it.
# Arguments: modality name selector mapping K seed projector config textbank cache port
train_bake_eval () {
  local modality="$1"; local name="$2"; local selector="$3"; local mapping="$4"
  local K="$5"; local seed="$6"; local projector="$7"; local cfg="$8"
  local textbank="$9"; local cache="${10}"; local port="${11}"

  local out="$TRAIN_ROOT/${modality}_${name}_seed${seed}"
  local proj="paper_${RUN_TAG}_${modality}_${name}_s${seed}"

  if [[ ! -f "$out/W_last.pt" ]]; then
    echo "[TRAIN] ${modality} ${name} selector=${selector} mapping=${mapping} K=${K} seed=${seed}"
    CUDA_VISIBLE_DEVICES="$GPU" PYTHONUNBUFFERED=1 \
    python "$SUITE/train_relproto_variant.py" \
      --project_root . \
      --train_dataset "$cache" \
      --text_bank "$textbank" \
      --model_config "$cfg" \
      --weights "$projector" \
      --out_dir "$out" \
      --selector "$selector" \
      --mapping "$mapping" \
      --prototype_max_patches "$K" \
      --epochs "$EPOCHS_W" \
      --batch_size "$BATCH_W" \
      --lr "$LR_W" \
      --seed "$seed" \
      --expected_bg_thresh "$BG_THRESH" \
      --require_pamr \
      --require_cache_projector_match \
      --device cuda \
      2>&1 | tee "$RUN_ROOT/logs/train_${modality}_${name}_seed${seed}.log"
  else
    echo "[REUSE] $out/W_last.pt"
  fi

  if [[ ! -f "weights/${proj}.pth" ]]; then
    python "$SUITE/bake_transform.py" \
      --projector "$projector" \
      --transform_checkpoint "$out/W_last.pt" \
      --model_config "$cfg" \
      --output "weights/${proj}.pth"
  fi

  if [[ "$modality" == "clip" ]]; then
    eval_clip "$proj" "${modality}_${name}_seed${seed}" "$port"
  else
    eval_llama "$proj" "${modality}_${name}_seed${seed}" "$port"
  fi
}

# -----------------------------------------------------------------------------
# A. CLIP: paper component ablation + L ablation
# -----------------------------------------------------------------------------
if [[ "$RUN_CLIP" == "1" ]]; then
  echo "[A0] CLIP Talk2DINO baseline"
  eval_clip "vitb_mlp_infonce_coco2014_reproduce_clean" "clip_baseline" 33101

  port=33200
  # Paper component table:
  #   Absolute + Linear      : absolute top-1 visual evidence
  #   Relative + Linear      : relative evidence, default L=4
  #   Relative + Orthogonal  : relative evidence, default L=4
  for SEED in $SEEDS; do
    port=$((port+1)); train_bake_eval clip absolute_linear absolute linear 1 "$SEED" "$CLIP_WEIGHT" "$CLIP_CFG" "$CLIP_PART_BANK" "$CLIP_CACHE" "$port"
    port=$((port+1)); train_bake_eval clip relative_linear relative linear 4 "$SEED" "$CLIP_WEIGHT" "$CLIP_CFG" "$CLIP_PART_BANK" "$CLIP_CACHE" "$port"
    port=$((port+1)); train_bake_eval clip relative_orth_L4 relative orthogonal 4 "$SEED" "$CLIP_WEIGHT" "$CLIP_CFG" "$CLIP_PART_BANK" "$CLIP_CACHE" "$port"
  done

  # Paper RelProto support-size ablation: L={1,2,4,6,8}.
  # L=4 reuses the component-table output above.
  for K in 1 2 6 8; do
    for SEED in $SEEDS; do
      port=$((port+1)); train_bake_eval clip "relative_orth_L${K}" relative orthogonal "$K" "$SEED" "$CLIP_WEIGHT" "$CLIP_CFG" "$CLIP_PART_BANK" "$CLIP_CACHE" "$port"
    done
  done
fi

# -----------------------------------------------------------------------------
# B. LLaMA3 robustness: rebuild PredObj cache at bg=0.55 with PAMR, then run
# the same four-row table as the paper.
# -----------------------------------------------------------------------------
if [[ "$RUN_LLAMA" == "1" ]]; then
  if [[ ! -f "$LLAMA_OBJ_BANK" ]]; then
    echo "[B0] build 20-class LLaMA3 object raw-text bank"
    CUDA_VISIBLE_DEVICES="$GPU" PYTHONUNBUFFERED=1 \
    python extract_llama3_text_bank.py \
      --classes \
        aeroplane bicycle bird boat bottle bus car cat chair cow \
        diningtable dog horse motorbike person pottedplant sheep sofa train tvmonitor \
      --out_path "$LLAMA_OBJ_BANK" \
      --prompt_mode obj \
      --num_epochs 8 \
      --response_pool mean \
      --master_port 33901 \
      2>&1 | tee "$RUN_ROOT/logs/llama_object_bank.log"
  fi

  if [[ ! -f "$LLAMA_CACHE" ]]; then
    echo "[B1] rebuild LLaMA3 PredObj cache: bg=0.55 + PAMR"
    CUDA_VISIBLE_DEVICES="$GPU" PYTHONUNBUFFERED=1 \
    python "$SUITE/extract_predobj_with_raw_text.py" \
      --raw_object_bank "$LLAMA_OBJ_BANK" \
      --repo_root . \
      --image_root "$IMAGE_ROOT" \
      --obj_mask_root "$OBJ_ROOT" \
      --part_mask_root "$PART_ROOT" \
      --obj_mask_mode zero_based \
      --obj_ignore 255 \
      --part_id_offset 0 \
      --part_ignore 255 \
      --projector_weight "$LLAMA_WEIGHT" \
      --model_name dinov2_vitb14_reg \
      --proj_class vitb_mlp_infonce_llama4096_overnight_v1 \
      --proj_model ProjectionLayer \
      --bg_thresh "$BG_THRESH" \
      --lambda_bg 0.2 \
      --pamr \
      --eval_max_long 2048 \
      --eval_max_short 448 \
      --slide_crop 448 \
      --slide_stride 224 \
      --crop_expand_ratio 1.2 \
      --crop_batch_size 16 \
      --output_pth "$LLAMA_CACHE" \
      --device cuda \
      2>&1 | tee "$RUN_ROOT/logs/build_llama_cache_bg055.log"
  else
    echo "[REUSE] $LLAMA_CACHE"
  fi

  echo "[B2] LLaMA3 Talk2DINO baseline"
  eval_llama "$LLAMA_PROJ_NAME" "llama_baseline" 34101

  port=34200
  for SEED in $SEEDS; do
    port=$((port+1)); train_bake_eval llama absolute_linear absolute linear 1 "$SEED" "$LLAMA_WEIGHT" "$LLAMA_CFG" "$LLAMA_PART_BANK" "$LLAMA_CACHE" "$port"
    port=$((port+1)); train_bake_eval llama relative_linear relative linear 4 "$SEED" "$LLAMA_WEIGHT" "$LLAMA_CFG" "$LLAMA_PART_BANK" "$LLAMA_CACHE" "$port"
    port=$((port+1)); train_bake_eval llama relative_orth_L4 relative orthogonal 4 "$SEED" "$LLAMA_WEIGHT" "$LLAMA_CFG" "$LLAMA_PART_BANK" "$LLAMA_CACHE" "$port"
  done
fi

# -----------------------------------------------------------------------------
# C. Post-hoc correspondence analysis across training epochs.
# Baseline is horizontal; Linear and Ours are evaluated at every epoch.
# -----------------------------------------------------------------------------
if [[ "$RUN_CORRESPONDENCE" == "1" ]]; then
  if [[ -f "$GT_VISUAL_CACHE" ]]; then
    echo "[C] correspondence analysis"
    CUDA_VISIBLE_DEVICES="$GPU" python "$SUITE/correspondence_analysis.py" \
      --text_bank "$CLIP_PART_BANK" \
      --model_config "$CLIP_CFG" \
      --projector "$CLIP_WEIGHT" \
      --gt_visual_cache "$GT_VISUAL_CACHE" \
      --label Talk2DINO_Part \
      --out_dir "$RUN_ROOT/correspondence" \
      --device cuda

    for SEED in $SEEDS; do
      for E in $(seq 1 "$EPOCHS_W"); do
        EE=$(printf "%03d" "$E")
        L="$TRAIN_ROOT/clip_relative_linear_seed${SEED}/W_epoch_${EE}.pt"
        O="$TRAIN_ROOT/clip_relative_orth_L4_seed${SEED}/W_epoch_${EE}.pt"
        if [[ -f "$L" ]]; then
          CUDA_VISIBLE_DEVICES="$GPU" python "$SUITE/correspondence_analysis.py" \
            --text_bank "$CLIP_PART_BANK" --model_config "$CLIP_CFG" \
            --projector "$CLIP_WEIGHT" --w_checkpoint "$L" \
            --gt_visual_cache "$GT_VISUAL_CACHE" \
            --label "Linear_seed${SEED}_epoch${EE}" \
            --out_dir "$RUN_ROOT/correspondence" --device cuda
        fi
        if [[ -f "$O" ]]; then
          CUDA_VISIBLE_DEVICES="$GPU" python "$SUITE/correspondence_analysis.py" \
            --text_bank "$CLIP_PART_BANK" --model_config "$CLIP_CFG" \
            --projector "$CLIP_WEIGHT" --w_checkpoint "$O" \
            --gt_visual_cache "$GT_VISUAL_CACHE" \
            --label "Ours_seed${SEED}_epoch${EE}" \
            --out_dir "$RUN_ROOT/correspondence" --device cuda
        fi
      done
    done
    python "$SUITE/aggregate_correspondence_epochs.py" \
      --input_dir "$RUN_ROOT/correspondence" \
      --output_csv "$RUN_ROOT/correspondence_epoch_curves.csv"
  else
    echo "[SKIP] GT visual cache not found: $GT_VISUAL_CACHE" | tee "$RUN_ROOT/logs/correspondence_skip.log"
  fi
fi

# -----------------------------------------------------------------------------
# D. Extra requested experiment: evaluate EVERY epoch 001..100 from the
# existing final main run. Each epoch is baked then evaluated with PAMR=false.
# This is intentionally LAST.
# -----------------------------------------------------------------------------
if [[ "$RUN_EPOCH_SWEEP" == "1" ]]; then
  echo "[D] epoch 001..100 mIoU sweep"
  GPU="$GPU" \
  RUN_ROOT="$RUN_ROOT" \
  EPOCH_SWEEP_DIR="$EPOCH_SWEEP_DIR" \
  CLIP_WEIGHT="$CLIP_WEIGHT" \
  CLIP_PART_BANK="$CLIP_PART_BANK" \
  CLIP_CFG="$CLIP_CFG" \
  bash "$SUITE/epoch_sweep_001_100.sh" \
    2>&1 | tee "$RUN_ROOT/logs/epoch_sweep_001_100.log"
fi

python "$SUITE/summarize_suite.py" --run_root "$RUN_ROOT" \
  2>&1 | tee "$RUN_ROOT/logs/final_summary.log"

python "$SUITE/repo_guard.py" verify --repo . --state "$RUN_ROOT/tracked_files_before.json"

echo
echo "============================================================"
echo "PAPER NIGHTLY SUITE COMPLETE"
echo "results : $RUN_ROOT"
echo "train   : $TRAIN_ROOT"
echo "features: $FEATURE_ROOT"
echo "============================================================"
