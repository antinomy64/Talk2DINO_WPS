#!/usr/bin/env python3
from __future__ import annotations
import argparse, importlib
from pathlib import Path
from typing import Mapping, Any
import torch, yaml

def tload(path):
    try:
        return torch.load(str(path), map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(str(path), map_location="cpu")

def unwrap(obj):
    if isinstance(obj, Mapping):
        for key in ("state_dict","model_state_dict","projector_state_dict"):
            if key in obj and isinstance(obj[key], Mapping):
                obj=obj[key]; break
    if not isinstance(obj, Mapping):
        raise TypeError("bad state_dict")
    s={str(k):v.detach().cpu().clone() for k,v in obj.items() if torch.is_tensor(v)}
    if s and all(k.startswith("module.") for k in s):
        s={k[7:]:v for k,v in s.items()}
    return s

def final_keys(state):
    hidden=[]
    for k in state:
        if k.startswith("hidden_layers.") and k.endswith(".weight"):
            p=k.split(".")
            if len(p)==3 and p[1].isdigit(): hidden.append(int(p[1]))
    if hidden:
        i=max(hidden); return f"hidden_layers.{i}.weight",f"hidden_layers.{i}.bias"
    if "linear_layer2.weight" in state:
        return "linear_layer2.weight","linear_layer2.bias"
    return "linear_layer.weight","linear_layer.bias"

def main():
    p=argparse.ArgumentParser()
    p.add_argument("--projector",required=True)
    p.add_argument("--transform_checkpoint",required=True)
    p.add_argument("--model_config",required=True)
    p.add_argument("--output",required=True)
    a=p.parse_args()
    pp,wp,cp,op=map(lambda x:Path(x).resolve(),[
        a.projector,a.transform_checkpoint,a.model_config,a.output
    ])
    for x in (pp,wp,cp):
        if not x.is_file(): raise FileNotFoundError(x)
    if op.exists(): raise FileExistsError(op)
    old=unwrap(tload(pp))
    ck=tload(wp)
    if not isinstance(ck,Mapping) or "W" not in ck: raise KeyError("W")
    A=torch.as_tensor(ck["W"]).float().cpu()
    if A.shape!=(768,768) or not torch.isfinite(A).all(): raise ValueError(A.shape)
    state={k:v.clone() for k,v in old.items()}
    wk,bk=final_keys(state)
    ow,ob=state[wk].float(),state[bk].float()
    if ow.shape[0]!=768 or ob.shape!=(768,): raise ValueError((ow.shape,ob.shape))
    state[wk]=(A.T@ow).to(state[wk].dtype)
    state[bk]=(ob@A).to(state[bk].dtype)

    cfg=yaml.safe_load(cp.read_text())["model"]
    cls=getattr(importlib.import_module("src.model"),cfg.get("model_class","ProjectionLayer"))
    m0,m1=cls.from_config(cfg),cls.from_config(cfg)
    m0.load_state_dict(old,strict=True); m1.load_state_dict(state,strict=True)
    m0.eval();m1.eval()
    dim=int(m0.linear_layer.in_features)
    torch.manual_seed(3407); x=torch.randn(17,dim)
    with torch.no_grad():
        exp=m0.project_clip_txt(x).float()@A
        got=m1.project_clip_txt(x).float()
    err=float((exp-got).abs().max())
    if err>1e-4: raise RuntimeError(f"bake verification failed {err}")
    op.parent.mkdir(parents=True,exist_ok=True)
    torch.save(state,op)
    print("BAKE_PASS",op,"max_abs_error=",err)

if __name__=="__main__": main()
