#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
from typing import Any, Mapping
import hashlib
import torch
import torch.nn.functional as F

def tload(path):
    try:
        return torch.load(str(path), map_location="cpu", weights_only=False)
    except TypeError:
        return torch.load(str(path), map_location="cpu")

def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for b in iter(lambda: f.read(8 << 20), b""):
            h.update(b)
    return h.hexdigest()

def load_raw_bank(path, expected_rows=None):
    path = Path(path).resolve()
    obj = tload(path)
    if not isinstance(obj, Mapping):
        raise TypeError(f"text bank is not a mapping: {path}")
    if "features" in obj:
        x = torch.as_tensor(obj["features"]).float().cpu()
    elif "raw_features" in obj:
        x = torch.as_tensor(obj["raw_features"]).float().cpu()
    else:
        raise KeyError("text bank needs features/raw_features")
    names = obj.get("class_names", obj.get("classnames", obj.get("names")))
    if names is None:
        raise KeyError("text bank needs class_names/classnames/names")
    names = [str(s) for s in names]
    if x.ndim != 2 or x.shape[0] != len(names):
        raise ValueError(f"bank shape/names mismatch: {tuple(x.shape)} vs {len(names)}")
    if expected_rows is not None and x.shape[0] != expected_rows:
        raise ValueError(f"expected {expected_rows} rows, got {x.shape[0]}")
    if obj.get("normalized", False) is not False:
        raise ValueError("nightly suite expects raw pre-projector bank: normalized=False")
    if not torch.isfinite(x).all() or bool((x.norm(dim=1) <= 1e-12).any()):
        raise ValueError("invalid/nonfinite/zero text features")
    return x.contiguous(), names, dict(obj)

@torch.inference_mode()
def project_bank(projector, raw, device="cuda", batch_size=128):
    dev = torch.device(device)
    out = []
    for s in range(0, raw.shape[0], batch_size):
        y = projector.project_clip_txt(raw[s:s+batch_size].to(dev, dtype=torch.float32))
        if y.ndim != 2 or y.shape[1] != 768:
            raise ValueError(f"projector returned {tuple(y.shape)}")
        out.append(y.float().cpu())
    return F.normalize(torch.cat(out, 0), dim=-1).contiguous()

def jsonable(x: Any):
    import numpy as np
    if torch.is_tensor(x):
        return x.detach().cpu().tolist()
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, np.generic):
        return x.item()
    if isinstance(x, Mapping):
        return {str(k): jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [jsonable(v) for v in x]
    if isinstance(x, (str, int, float, bool)) or x is None:
        return x
    return str(x)
