#!/usr/bin/env python3
from __future__ import annotations
import argparse, csv, json, re
from pathlib import Path


def pct(v):
    if v is None:
        return None
    x = float(v)
    return x * 100.0 if abs(x) <= 1.5 else x


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--root', required=True)
    p.add_argument('--output_csv', required=True)
    a = p.parse_args()
    root = Path(a.root)
    rows = []
    for path in sorted(root.glob('epoch_*_metrics.json')):
        m = re.search(r'epoch_(\d+)_metrics$', path.stem)
        if not m:
            continue
        d = json.loads(path.read_text())
        metric = d.get('metric', {})
        rows.append({
            'epoch': int(m.group(1)),
            'mIoU': pct(metric.get('mIoU')) if metric.get('mIoU') is not None else d.get('miou_percent_from_main'),
            'mACC': pct(metric.get('mAcc')),
            'aACC': pct(metric.get('aAcc')),
            'metrics_file': str(path),
        })
    rows.sort(key=lambda x: x['epoch'])
    out = Path(a.output_csv)
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=['epoch','mIoU','mACC','aACC','metrics_file'])
        w.writeheader(); w.writerows(rows)
    if rows:
        best = max((r for r in rows if r['mIoU'] is not None), key=lambda r: r['mIoU'])
        print('epochs evaluated:', len(rows))
        print('best epoch:', best['epoch'])
        print('best mIoU:', best['mIoU'])
        print('best mACC:', best['mACC'])
    else:
        print('no epoch metrics found')

if __name__ == '__main__':
    main()
