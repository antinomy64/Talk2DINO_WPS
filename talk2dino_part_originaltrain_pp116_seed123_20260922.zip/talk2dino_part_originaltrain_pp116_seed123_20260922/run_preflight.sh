#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"; source "${PKG_DIR}/config.sh"; cd "${REPO_ROOT}"
if [[ -f "${SOURCE_DINO_CACHE}" ]]; then C="${SOURCE_DINO_CACHE}"; else C="${DINO_CACHE}"; fi
python "${PKG_DIR}/preflight.py" --repo_root "${REPO_ROOT}" --text_bank "${TEXT_BANK}" --model_config "${MODEL_CONFIG}" --base_projector "${BASE_PROJECTOR}" --dino_cache "$C" --eval_cfg "${EVAL_CFG}" --eval_base_cfg "${EVAL_BASE_CFG}"
