#!/usr/bin/env python3
"""Convert PP-116 image/part supervision to the exact COCO-like structure expected by DinoClipDataset.

One DINO visual record is kept per image. Every present part becomes one annotation
referencing that image, exactly analogous to COCO having multiple captions per image.
The annotation field `ann_feats` is taken verbatim from the same PP-116 CLIP text bank
used by Ours. No custom batching and no custom loss are introduced.
"""
import argparse
from pathlib import Path
import torch


def find_tensor(obj):
    if torch.is_tensor(obj):
        return obj
    if isinstance(obj, dict):
        for k in ('features', 'mean_feats', 'text_features', 'feats'):
            if k in obj and torch.is_tensor(obj[k]):
                return obj[k]
        ts = [v for v in obj.values() if torch.is_tensor(v) and v.ndim == 2]
        if len(ts) == 1:
            return ts[0]
    raise RuntimeError('Could not identify [num_classes, text_dim] tensor in text bank.')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dino_cache', required=True)
    ap.add_argument('--text_bank', required=True)
    ap.add_argument('--output', required=True)
    a = ap.parse_args()

    c = torch.load(a.dino_cache, map_location='cpu')
    heads = c['heads']
    records = c['records']
    if heads.ndim != 3 or len(records) != heads.shape[0]:
        raise RuntimeError(f'Bad DINO cache: heads={tuple(heads.shape)}, records={len(records)}')

    tb = find_tensor(torch.load(a.text_bank, map_location='cpu')).float().contiguous()
    if tb.ndim != 2 or tb.shape[0] != 116:
        raise RuntimeError(f'Expected text bank [116,D], got {tuple(tb.shape)}')

    images, annotations = [], []
    ann_id = 0
    for i, r in enumerate(records):
        image_id = i
        visual = heads[i].float().contiguous()
        # Original Talk2DINO val path uses avg_self_attn_out when training feature is
        # disentangled_self_attn. Mean over per-head embeddings is linear-equivalent
        # to averaging the per-head attention-weighted outputs.
        avg = visual.mean(dim=0)
        images.append({
            'id': image_id,
            'file_name': str(r.get('image_id', image_id)),
            'disentangled_self_attn': visual,
            'avg_self_attn_out': avg,
        })
        pids = sorted(set(int(x) for x in r['part_ids']))
        for pid in pids:
            if not (0 <= pid < tb.shape[0]):
                raise RuntimeError(f'Invalid part id {pid} in record {r}')
            annotations.append({
                'id': ann_id,
                'image_id': image_id,
                'caption': f'part_{pid}',  # metadata only; training reads ann_feats
                'part_id': pid,
                'ann_feats': tb[pid].clone(),
            })
            ann_id += 1

    if not annotations:
        raise RuntimeError('No image-part annotations were produced.')

    payload = {
        'images': images,
        'annotations': annotations,
        'meta': {
            'format': 'Talk2DINO DinoClipDataset COCO-like format',
            'num_images': len(images),
            'num_annotations': len(annotations),
            'visual_feature': 'disentangled_self_attn',
            'text_feature': 'ann_feats',
            'same_text_bank_as_ours': str(Path(a.text_bank).resolve()),
            'sampling_semantics': 'multiple part annotations per image, analogous to multiple COCO captions per image',
        }
    }
    out = Path(a.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(payload, out)
    print(f'Saved original-format dataset: {out}')
    print(f'images={len(images)} annotations(image-part pairs)={len(annotations)}')
    print(f'heads={tuple(heads.shape)} text_bank={tuple(tb.shape)}')


if __name__ == '__main__':
    main()
