# Talk2DINO-Part PP-116 — original training-flow revision

This revision replaces the previous custom trainer. The previous 14.45 mIoU result should be treated as preliminary/invalid for the formal baseline.

## What is different now

The training path is now deliberately the same as repository `train.py`:

1. `DinoClipDataset`
2. `ProjectionLayer.from_config(...)`
3. initialize from `weights/vitb_mlp_infonce_coco2014_reproduce_clean.pth`
4. repository `src.train_util.do_train(...)`
5. repository optimizer/scheduler interface (`Adam`, weight decay 0.05, linear scheduler, warmup 0)
6. save projector and run the existing PP-116 full-image evaluator with `evaluate.pamr=false`

There is **no custom batch sampler, no custom cross-entropy implementation, and no custom optimizer loop** in this package.

## How PP-116 is presented to original DinoClipDataset

`build_original_dataset.py` creates the same COCO-like structure used by Talk2DINO:

- one `images` record per PP-116 training image;
- multiple `annotations` per image, one for each present part;
- `images[*].disentangled_self_attn` = Talk2DINO DINO head visual embeddings;
- `annotations[*].ann_feats` = the exact same PP-116 CLIP text-bank vector used by Ours.

This mirrors original COCO training, where one image has multiple caption annotations. Therefore duplicate images/semantic labels inside a batch are left to the **original Talk2DINO DataLoader/do_train behavior** instead of being filtered by a custom sampler.

## Target-stage controlled settings

- seed: 123
- epochs: 30
- batch size: 16
- lr: 1e-5
- initialization: reproduced COCO Captions 2014 Talk2DINO projector
- final evaluation: PP-116 full-image, PAMR disabled

The script only overrides these keys if they already exist in the repository `config['train']`; otherwise it aborts rather than silently changing the training API.

## Reuse of previous expensive extraction

If this exists:

`talk2dino_part_pp116_seed123_20260922/cache/pp116_dino_heads.pt`

it is reused directly. Therefore rerunning this corrected baseline should normally skip DINO extraction.

## Run

Unzip at repository root, then:

```bash
bash talk2dino_part_originaltrain_pp116_seed123_20260922/run_preflight.sh
```

and:

```bash
nohup bash talk2dino_part_originaltrain_pp116_seed123_20260922/run_all.sh \
  > talk2dino_part_originaltrain_pp116_seed123_20260922/nohup.out 2>&1 &

echo $!
```

Monitor:

```bash
tail -f talk2dino_part_originaltrain_pp116_seed123_20260922/nohup.out
```

Final CSV:

`talk2dino_part_originaltrain_pp116_seed123_20260922/results/talk2dino_part_originaltrain_seed123.csv`
