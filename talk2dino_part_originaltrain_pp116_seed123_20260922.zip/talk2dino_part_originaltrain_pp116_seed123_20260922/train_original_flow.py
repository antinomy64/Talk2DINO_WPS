#!/usr/bin/env python3
"""Talk2DINO-Part target adaptation using repository-original DinoClipDataset + do_train.

This intentionally mirrors the official train.py flow. The only target-task additions are:
  1) initialize ProjectionLayer from the reproduced COCO2014 Talk2DINO projector;
  2) optionally override target-stage epochs/batch-size/lr for the controlled comparison;
  3) write the final projector to an explicit isolated path.
No custom DataLoader, batch sampler, InfoNCE implementation, or optimizer loop exists here.
"""
import argparse
import importlib
import inspect
import os
from pathlib import Path
import sys
import torch
import yaml


def unwrap_state_dict(obj):
    if isinstance(obj, dict):
        for k in ('model', 'state_dict', 'projector', 'projection_layer'):
            if k in obj and isinstance(obj[k], dict):
                return unwrap_state_dict(obj[k])
    return obj


def set_first(cfg, names, value, label, required=True):
    for n in names:
        if n in cfg:
            old = cfg[n]
            cfg[n] = value
            print(f'[config] {label}: {n} {old!r} -> {value!r}')
            return n
    if required:
        raise KeyError(f'Could not find {label} key among {names}; train config keys={sorted(cfg.keys())}')
    return None


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--project_root', required=True)
    p.add_argument('--dataset', required=True)
    p.add_argument('--model_config', required=True)
    p.add_argument('--base_weights', required=True)
    p.add_argument('--output', required=True)
    p.add_argument('--epochs', type=int, default=30)
    p.add_argument('--batch_size', type=int, default=16)
    p.add_argument('--lr', type=float, default=1e-5)
    p.add_argument('--seed', type=int, default=123)
    p.add_argument('--optimizer', default='Adam')
    p.add_argument('--weight_decay', type=float, default=0.05)
    p.add_argument('--scheduler', default='linear')
    p.add_argument('--warmup', type=int, default=0)
    a = p.parse_args()

    root = Path(a.project_root).resolve()
    sys.path.insert(0, str(root))
    from src.dataset import DinoClipDataset
    from src.train_util import do_train, set_seed

    set_seed(a.seed)
    with open(a.model_config, 'r') as f:
        config = yaml.safe_load(f)
    if not isinstance(config, dict) or 'model' not in config or 'train' not in config:
        raise RuntimeError('Model config must contain top-level model and train sections.')

    train_cfg = dict(config['train'])
    # Keep do_train unchanged; only update its existing target-stage hyperparameter fields.
    set_first(train_cfg, ('epochs', 'num_epochs', 'n_epochs'), a.epochs, 'epochs')
    set_first(train_cfg, ('batch_size', 'batch'), a.batch_size, 'batch size')
    set_first(train_cfg, ('lr', 'learning_rate'), a.lr, 'learning rate')

    model_class_name = config['model'].get('model_class', 'ProjectionLayer')
    ModelClass = getattr(importlib.import_module('src.model'), model_class_name)
    model = ModelClass.from_config(config['model'])
    sd = unwrap_state_dict(torch.load(a.base_weights, map_location='cpu'))
    model.load_state_dict(sd, strict=True)
    model.to('cuda')

    # EXACT same dataset class/feature names used by official train.py.
    train_dataset = DinoClipDataset(
        a.dataset,
        features_name='disentangled_self_attn',
        text_features='ann_feats',
        load_attn_maps=False,
        is_wds=False,
    )
    # Official train.py switches val visual feature to avg_self_attn_out for this mode.
    val_dataset = DinoClipDataset(
        a.dataset,
        features_name='avg_self_attn_out',
        text_features='ann_feats',
        load_attn_maps=False,
        is_wds=False,
    )

    print('=== ORIGINAL TALK2DINO TRAINING FLOW ===')
    print('Dataset class:', type(train_dataset))
    print('do_train module:', do_train.__module__)
    print('do_train signature:', inspect.signature(do_train))
    print('optimizer/scheduler:', a.optimizer, a.weight_decay, a.scheduler, a.warmup)
    print('train config:', train_cfg)
    print('initial weights:', Path(a.base_weights).resolve())

    model, train_losses, val_losses = do_train(
        model,
        train_dataset,
        val_dataset,
        train_cfg,
        optimizer_name=a.optimizer,
        weight_decay=a.weight_decay,
        scheduler_name=a.scheduler,
        warmup=a.warmup,
    )

    out = Path(a.output).resolve(); out.parent.mkdir(parents=True, exist_ok=True)
    torch.save(model.state_dict(), out)
    torch.save({'train_losses': train_losses, 'val_losses': val_losses}, out.with_suffix('.losses.pt'))
    print(f'Saved evaluator-compatible projector: {out}')


if __name__ == '__main__':
    main()
