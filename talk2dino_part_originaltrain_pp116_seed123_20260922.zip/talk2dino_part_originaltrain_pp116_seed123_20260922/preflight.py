#!/usr/bin/env python3
import argparse, inspect, sys
from pathlib import Path
import torch, yaml


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--repo_root', required=True)
    p.add_argument('--text_bank', required=True)
    p.add_argument('--model_config', required=True)
    p.add_argument('--base_projector', required=True)
    p.add_argument('--dino_cache', required=True)
    p.add_argument('--eval_cfg', required=True)
    p.add_argument('--eval_base_cfg', required=True)
    a=p.parse_args()
    for x in (a.text_bank,a.model_config,a.base_projector,a.dino_cache,a.eval_cfg,a.eval_base_cfg):
        if not Path(x).is_file(): raise FileNotFoundError(x)
    root=Path(a.repo_root).resolve(); sys.path.insert(0,str(root))
    from src.dataset import DinoClipDataset
    from src.train_util import do_train
    from src.model import ProjectionLayer
    with open(a.model_config) as f: cfg=yaml.safe_load(f)
    print('DinoClipDataset:', inspect.signature(DinoClipDataset))
    print('do_train:', inspect.signature(do_train))
    print('train config:', cfg.get('train'))
    print('model keys:', cfg.get('model',{}).keys())
    c=torch.load(a.dino_cache,map_location='cpu')
    print('DINO heads:', tuple(c['heads'].shape), 'records:', len(c['records']))
    print('=== preflight OK ===')

if __name__=='__main__': main()
