#!/usr/bin/env bash
set -euo pipefail
PKG_DIR="$(cd "$(dirname "$0")" && pwd)"
source "${PKG_DIR}/config.sh"
cd "${REPO_ROOT}"
mkdir -p "${PKG_DIR}/cache" "$(dirname "${FINAL_WEIGHT}")" "${LOG_DIR}" "${RESULT_DIR}" "${EVAL_OUTPUT}"
exec > >(tee -a "${LOG_DIR}/run_all.log") 2>&1

echo "=== Talk2DINO-Part: ORIGINAL train.py/do_train flow | seed=${SEED} ==="
echo "Start: $(date -Is)"

# Reuse previous full-image DINO head cache when available; otherwise reproduce it.
if [[ -f "${SOURCE_DINO_CACHE}" ]]; then
  ACTIVE_DINO_CACHE="${SOURCE_DINO_CACHE}"
  echo "[reuse] previous DINO head cache: ${ACTIVE_DINO_CACHE}"
else
  ACTIVE_DINO_CACHE="${DINO_CACHE}"
  if [[ ! -f "${MANIFEST}" ]]; then
    python "${PKG_DIR}/build_part_presence.py" \
      --image_root "${IMAGE_ROOT}" --part_mask_root "${PART_MASK_ROOT}" \
      --output "${MANIFEST}" --ignore "${PART_IGNORE}" \
      --id_offset "${PART_ID_OFFSET}" --num_classes "${NUM_PART_CLASSES}" \
      2>&1 | tee "${LOG_DIR}/01_part_presence.log"
  fi
  if [[ ! -f "${ACTIVE_DINO_CACHE}" ]]; then
    EXTRA=(); [[ -n "${DINO_REPO}" ]] && EXTRA+=(--dino_repo "${DINO_REPO}")
    python "${PKG_DIR}/extract_dino_heads.py" \
      --project_root "${REPO_ROOT}" --manifest "${MANIFEST}" --output "${ACTIVE_DINO_CACHE}" \
      "${EXTRA[@]}" --dino_ckpt "${DINO_CKPT}" --model_name "${DINO_MODEL}" \
      --input_size "${DINO_INPUT_SIZE}" --batch_size "${EXTRACT_BATCH_SIZE}" \
      --num_workers "${NUM_WORKERS}" --dtype "${EXTRACT_DTYPE}" --device "${DEVICE}" --seed "${SEED}" \
      2>&1 | tee "${LOG_DIR}/02_extract_dino_heads.log"
  fi
fi

python "${PKG_DIR}/preflight.py" \
  --repo_root "${REPO_ROOT}" --text_bank "${TEXT_BANK}" --model_config "${MODEL_CONFIG}" \
  --base_projector "${BASE_PROJECTOR}" --dino_cache "${ACTIVE_DINO_CACHE}" \
  --eval_cfg "${EVAL_CFG}" --eval_base_cfg "${EVAL_BASE_CFG}" \
  2>&1 | tee "${LOG_DIR}/00_preflight.log"

python "${PKG_DIR}/build_original_dataset.py" \
  --dino_cache "${ACTIVE_DINO_CACHE}" --text_bank "${TEXT_BANK}" --output "${ORIGINAL_DATASET}" \
  2>&1 | tee "${LOG_DIR}/03_build_original_dataset.log"

python "${PKG_DIR}/train_original_flow.py" \
  --project_root "${REPO_ROOT}" --dataset "${ORIGINAL_DATASET}" \
  --model_config "${MODEL_CONFIG}" --base_weights "${BASE_PROJECTOR}" --output "${FINAL_WEIGHT}" \
  --epochs "${EPOCHS}" --batch_size "${BATCH_SIZE}" --lr "${LR}" --seed "${SEED}" \
  --optimizer "${OPTIMIZER}" --weight_decay "${WEIGHT_DECAY}" --scheduler "${SCHEDULER}" --warmup "${WARMUP}" \
  2>&1 | tee "${LOG_DIR}/04_train_original_flow.log"

PROJ_REL="../$(basename "${PKG_DIR}")/weights/$(basename "${FINAL_WEIGHT}" .pth)"
python -m torch.distributed.run \
  --nproc_per_node=1 --master_port="${MASTER_PORT}" \
  src/open_vocabulary_segmentation/main.py --eval --output "${EVAL_OUTPUT}" \
  --eval_cfg "${EVAL_CFG}" --eval_base_cfg "${EVAL_BASE_CFG}" \
  --opts model.proj_name="${PROJ_REL}" evaluate.pamr=false \
  2>&1 | tee "${LOG_DIR}/05_eval.log"

python "${PKG_DIR}/summarize_result.py" \
  --eval_log "${LOG_DIR}/05_eval.log" --output "${RESULT_DIR}/talk2dino_part_originaltrain_seed123.csv" \
  2>&1 | tee "${LOG_DIR}/06_summary.log"

echo "Done: $(date -Is)"
echo "Result: ${RESULT_DIR}/talk2dino_part_originaltrain_seed123.csv"
